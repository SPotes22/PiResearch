# agi_master_api.py
from flask import Flask, jsonify, request, render_template
from flask_cors import CORS
import pickle
import numpy as np
import pandas as pd
import json
from datetime import datetime
import threading
import time

app = Flask(__name__)
CORS(app)  # ✅ Permite conexiones desde tu navegador

class AGIMasterAPI:
    def __init__(self):
        self.models = {}
        self.datasets = {}
        self.prediction_history = []
        self.dashboard_data = {
            'models_loaded': [],
            'datasets_loaded': [],
            'predictions_count': 0,
            'security_blocks': 0
        }
    
    def load_model(self, model_name, model_path):
        """Cargar modelo .pkl via API"""
        try:
            with open(model_path, 'rb') as f:
                self.models[model_name] = pickle.load(f)
            self.dashboard_data['models_loaded'].append(model_name)
            return True
        except Exception as e:
            return False
    
    def predict(self, model_name, input_text, flags=None):
        """Predecir via API"""
        try:
            # Validación de seguridad
            if flags.get('validate_input', True):
                if self._is_dangerous_input(input_text):
                    self.dashboard_data['security_blocks'] += 1
                    return {"error": "Input bloqueado por seguridad"}
            
            # Obtener predicción
            model_data = self.models[model_name]
            X = model_data['vectorizer'].transform([input_text])
            probabilities = model_data['model'].predict_proba(X)[0]
            prediction = model_data['model'].predict(X)[0]
            confidence = max(probabilities)
            
            # Loggear
            log_entry = {
                'timestamp': datetime.now().isoformat(),
                'model': model_name,
                'input': input_text[:100],
                'prediction': int(prediction),
                'confidence': float(confidence),
                'flags': flags
            }
            self.prediction_history.append(log_entry)
            self.dashboard_data['predictions_count'] += 1
            
            return {
                'prediction': int(prediction),
                'confidence': float(confidence),
                'malicious': bool(prediction),
                'status': 'success'
            }
            
        except Exception as e:
            return {"error": str(e)}
    
    def _is_dangerous_input(self, text):
        """Validar input peligroso"""
        dangerous_patterns = [
            '<script>', '<?php', 'system(', 'eval(', 'exec(',
            'drop table', 'rm -rf', 'format c:', 'shutdown'
        ]
        return any(pattern in text.lower() for pattern in dangerous_patterns)

# Inicializar sistema
agi_system = AGIMasterAPI()

# RUTAS DE LA API
@app.route('/')
def dashboard():
    """Dashboard principal"""
    return """
    <html>
    <head>
        <title>AGI Master Dashboard</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            .card { border: 1px solid #ddd; padding: 15px; margin: 10px; border-radius: 5px; }
            .malicious { background: #ffebee; }
            .normal { background: #e8f5e8; }
        </style>
    </head>
    <body>
        <h1>🧠 AGI Master Dashboard</h1>
        
        <div class="card">
            <h3>📊 Estadísticas</h3>
            <div id="stats">Cargando...</div>
        </div>
        
        <div class="card">
            <h3>🎯 Probar Modelo</h3>
            <input type="text" id="inputText" placeholder="Ingresa texto para analizar" style="width: 300px;">
            <button onclick="predict()">Analizar</button>
            <div id="result"></div>
        </div>
        
        <div class="card">
            <h3>📈 Historial</h3>
            <div id="history"></div>
        </div>
        
        <script>
            function updateDashboard() {
                fetch('/api/dashboard')
                    .then(r => r.json())
                    .then(data => {
                        document.getElementById('stats').innerHTML = `
                            Modelos: ${data.models_loaded.join(', ')}<br>
                            Predicciones: ${data.predictions_count}<br>
                            Bloqueos: ${data.security_blocks}
                        `;
                    });
                
                fetch('/api/history')
                    .then(r => r.json())
                    .then(history => {
                        let html = '';
                        history.slice(-10).forEach(item => {
                            const cls = item.prediction ? 'malicious' : 'normal';
                            html += `<div class="card ${cls}">
                                <strong>${item.prediction ? '🚨 MALICIOSO' : '✅ NORMAL'}</strong> 
                                (${(item.confidence * 100).toFixed(1)}%)<br>
                                ${item.input}<br>
                                <small>${item.timestamp}</small>
                            </div>`;
                        });
                        document.getElementById('history').innerHTML = html;
                    });
            }
            
            function predict() {
                const text = document.getElementById('inputText').value;
                fetch('/api/predict', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({text: text, model: 'security_model'})
                })
                .then(r => r.json())
                .then(result => {
                    const cls = result.malicious ? 'malicious' : 'normal';
                    document.getElementById('result').innerHTML = `
                        <div class="card ${cls}">
                            <strong>${result.malicious ? '🚨 MALICIOSO' : '✅ NORMAL'}</strong><br>
                            Confianza: ${(result.confidence * 100).toFixed(1)}%<br>
                            Status: ${result.status}
                        </div>
                    `;
                    updateDashboard();
                });
            }
            
            // Actualizar cada 3 segundos
            setInterval(updateDashboard, 3000);
            updateDashboard();
        </script>
    </body>
    </html>
    """

@app.route('/api/dashboard')
def api_dashboard():
    """API: Datos del dashboard"""
    return jsonify(agi_system.dashboard_data)

@app.route('/api/history')
def api_history():
    """API: Historial de predicciones"""
    return jsonify(agi_system.prediction_history[-20:])  # Últimas 20

# CORRECCIÓN EN agi_master_api.py

# En la función initialize_system():
def initialize_system():
    time.sleep(1)
    # Cargar múltiples modelos
    agi_system.load_model('security_v1', 'modelo_real.pkl')
    agi_system.load_model('security_v2', 'security_model.pkl') 
    #agi_system.load_model('spam_detector', 'ethical_agent.pkl')
    """
    -rw-r--r-- 1 arachne arachne  42557 Oct  4 20:17 modelo_real.pkl
    -rw-r--r-- 1 arachne arachne 344492 Sep 30 15:54 security_model.pkl
    """
    print("✅ Modelos cargados: security_v1, security_v2 ")

# Y en el predict, usar el NOMBRE:
@app.route('/api/predict', methods=['POST'])
def api_predict():
    data = request.json
    # Usar 'security_model' no la ruta del archivo
    result = agi_system.predict(
        'security_model',  # ✅ NOMBRE del modelo cargado
        data['text'],
        flags=data.get('flags', {})
    )
    return jsonify(result)

@app.route('/api/load_model', methods=['POST'])
def api_load_model():
    """API: Cargar nuevo modelo"""
    data = request.json
    success = agi_system.load_model(data['name'], data['path'])
    return jsonify({'success': success})

# INICIALIZACIÓN AUTOMÁTICA
def initialize_system():
    """Cargar modelo base al iniciar"""
    time.sleep(1)
    agi_system.load_model('security_model', 'modelo_real.pkl')
    print("✅ Modelo de seguridad cargado automáticamente")

# Ejecutar en segundo plano
threading.Thread(target=initialize_system, daemon=True).start()

if __name__ == '__main__':
    print("🚀 AGI Master API iniciando...")
    print("📊 Dashboard disponible en: http://localhost:5000")
    print("🔧 API disponible en: http://localhost:5000/api/")
    app.run(host='0.0.0.0', port=5000, debug=True)
