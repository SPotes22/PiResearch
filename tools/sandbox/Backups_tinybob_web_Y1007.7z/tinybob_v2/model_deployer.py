# La arañita toma la mochila mágica (.pkl)
# Y puede usarla para responder preguntas
# ¡Y hace el 81% del trabajo automáticamente!
# El 20% restante es para tus ideas especiales
# model_deployer.py
import pickle
import numpy as np

class AGIMagica:
    def __init__(self, modelo_path='agi_transformer_magico.pkl'):
        """Carga la AGI entrenada desde el .pkl"""
        print("🎒 ABRIENDO MOCHILA MÁGICA...")
        with open(modelo_path, 'rb') as f:
            self.paquete = pickle.load(f)

        self.tokenizer = self.paquete['tokenizer']
        self.transformer = self.paquete['transformer_model']
        self.clasificador = self.paquete['clasificador']

        print(f"✅ AGI CARGADA - Accuracy: {self.paquete['accuracy_final']:.2%}")

    def predecir(self, texto):
        """La AGI responde usando lo aprendido"""
        # Tokenizar nuevo texto
        inputs = self.tokenizer(
            [texto], padding=True, truncation=True,
            return_tensors="tf", max_length=128
        )

        # Generar embedding
        outputs = self.transformer(inputs)
        embedding = outputs.last_hidden_state[:, 0, :].numpy()

        # Predecir
        prediccion = self.clasificador.predict(embedding)
        clase_predicha = np.argmax(prediccion, axis=1)[0]
        confianza = np.max(prediccion, axis=1)[0]

        return {
            'clase': 'ATAQUE' if clase_predicha == 1 else 'NORMAL',
            'confianza': f"{confianza:.2%}",
            'texto_analizado': texto
        }

    def hacer_81_del_trabajo(self, textos):
        """Hace automáticamente el 81% del trabajo"""
        print("🤖 AGI HACIENDO EL 81% DEL TRABAJO...")
        resultados = []

        for texto in textos:
            resultado = self.predecir(texto)
            resultados.append(resultado)
            print(f"🔍 {resultado['clase']} ({resultado['confianza']}) - {texto[:50]}...")

        print(f"✅ COMPLETADO: {len(resultados)} análisis")
        return resultados

# EJEMPLO DE USO
if __name__ == "__main__":
    # 1. Cargar AGI entrenada
    mi_agi = AGIMagica()

    # 2. Textos para analizar (el 81% lo hace la AGI)
    textos_ejemplo = [
        "SELECT * FROM users WHERE id = 1",
        "Hola mundo normal",
        "<script>alert('xss')</script>",
        "/api/users/list"
    ]

    # 3. ¡La AGI hace el 81% del trabajo!
    resultados = mi_agi.hacer_81_del_trabajo(textos_ejemplo)

    print("\n🎯 EL 20% RESTANTE ES PARA TUS IDEAS ESPECIALES:")
    print("   - Puedes agregar reglas personalizadas")
    print("   - O conectar con tus sistemas")
    print("   - O guardar resultados en tu base de datos")
