# state_manager.py
import json
import os
from functools import wraps
from typing import Dict, Any, List

# CONTEXTO INMUTABLE: stack=python/docker/json/markdown
STATE_FILE = 'tin_tan_state.json'
DEFAULT_STATE = {"tan_history": [], "version": "1.0-MVP", "metadata": {}}

def singleton(cls):
    """Implementación de Singleton (MVP 81/20)"""
    instances = {}
    @wraps(cls)
    def get_instance(*args, **kwargs):
        if cls not in instances:
            instances[cls] = cls(*args, **kwargs)
        return instances[cls]
    return get_instance

@singleton
class StateManager:
    """Gestor de Estado Centralizado (Singleton) para PiTech"""
    
    def __init__(self):
        self._state = self._load_state()

    def _load_state(self) -> Dict[str, Any]:
        """Carga el estado del disco (JSON) o usa el default"""
        if os.path.exists(STATE_FILE):
            try:
                with open(STATE_FILE, 'r') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                # Recuperación simple: si falla, usa el default
                print(f"⚠️ [WARN] {STATE_FILE} corrupto. Usando estado por defecto.")
        return DEFAULT_STATE

    def _save_state(self):
        """Persiste el estado en el disco ('web4 un ping a la vez')"""
        with open(STATE_FILE, 'w') as f:
            json.dump(self._state, f, indent=2)

    def register_tan_event(self, tan_id: str, status: str, context: Dict = None):
        """Registra un evento TAN y guarda el estado"""
        event = {
            "tan_id": tan_id,
            "timestamp": os.getenv("EXEC_TIMESTAMP", "now"),
            "status": status,
            "context": context if context else {}
        }
        self._state["tan_history"].append(event)
        self._save_state()
        
    def get_history(self) -> List:
        return self._state.get("tan_history", [])

    def get_version(self) -> str:
        return self._state.get("version", "unknown")

# Bloque de prueba simple para validación Crostini
if __name__ == '__main__':
    mgr = StateManager()
    mgr.register_tan_event(
        tan_id="VALIDATION-PING",
        status="COMPLETADO",
        context={"module": "StateManager", "lines": 72}
    )
    print(f"✅ StateManager v{mgr.get_version()} OK. Eventos: {len(mgr.get_history())}")
    
# Backlog siguiente: "Implementar la clase SemanticAISystem, cargando la matriz pre-generada y añadiendo el método de composición lineal."
