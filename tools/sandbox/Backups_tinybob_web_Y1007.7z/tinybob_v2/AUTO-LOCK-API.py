# agi_master_api_EXEC.py
from flask import Flask, jsonify, request, session, render_template, redirect
from flask_cors import CORS
import pickle
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
import threading
import time
import os
import json
from datetime import datetime
from flask_session import Session
from werkzeug.security import generate_password_hash, check_password_hash
import mysql.connector
import requests

# Configuración de la aplicación Flask
app = Flask(__name__)
app.secret_key = 'super-secret-key1'
app.config['SESSION_TYPE'] = 'filesystem'
Session(app)
CORS(app)

# Función para conexión a BD (debes implementar según tu configuración)
def get_db():
    return mysql.connector.connect(
        host="localhost",
        user="tu_usuario",
        password="tu_password", 
        database="tu_base_de_datos"
    )

class AGIMasterSystem:
    def __init__(self):
        self.models = {}
        self.training_history = []
        self.dashboard_data = {'models_loaded': [], 'predictions_count': 0, 'retrain_count': 0}
        self.admin_tokens = {"local_admin_2024"}
        self.load_security_model()
    
    def load_security_model(self):
        """Cargar modelo de seguridad"""
        try:
            with open('modelo_real.pkl', 'rb') as f:
                model_data = pickle.load(f)
            
            if isinstance(model_data, dict) and 'model' in model_data and 'vectorizer' in model_data:
                self.models['security_model'] = model_data
                print("✅ AGI Security Model cargado exitosamente")
                return True
            else:
                print("❌ Formato de modelo inválido")
                return False
                
        except Exception as e:
            print(f"⚠️ No se pudo cargar modelo AGI: {e}")
            return False
    
    def predict_security(self, text):
        """Predecir si texto es malicioso"""
        if 'security_model' not in self.models:
            return {"error": "Modelo AGI no disponible"}
        
        try:
            model_data = self.models['security_model']
            X = model_data['vectorizer'].transform([text])
            probabilities = model_data['model'].predict_proba(X)[0]
            prediction = model_data['model'].predict(X)[0]
            confidence = max(probabilities)
            
            # Log
            self.dashboard_data['predictions_count'] += 1
            
            return {
                'malicious': bool(prediction),
                'confidence': float(confidence),
                'prediction': int(prediction),
                'status': 'success'
            }
        except Exception as e:
            return {"error": str(e)}
    
    def exec_admin_command(self, command_data, flags):
        """Ejecutar comandos admin con flags"""
        # Verificar --admin flag
        if '--admin' in flags:
            if not self._verify_admin_token(command_data.get('admin_token')):
                return {"error": "Admin token inválido. Solo disponible en local."}
        
        cmd_type = command_data.get('type', '')
        
        if cmd_type == 'security_scan':
            return self._security_scan_batch(command_data.get('texts', []))
        elif cmd_type == 'model_info':
            return self._get_model_info()
        elif cmd_type == 'health_check':
            return self._health_check()
        elif cmd_type == 'setup_database':
            return self._setup_database(command_data)
        elif cmd_type == 'create_admin_user':
            return self._create_admin_user(command_data)
        elif cmd_type == 'retrain_with_feedback':
            return self._retrain_with_feedback(command_data, '--dynamic' in flags)
        elif cmd_type == 'create_new_model':
            return self._create_new_model(command_data, '--dynamic' in flags)
        elif cmd_type == 'export_model':
            return self._export_model(command_data)
        else:
            return {"error": f"Comando no reconocido: {cmd_type}"}
    
    def _verify_admin_token(self, token):
        """Verificar token admin"""
        return token in self.admin_tokens
    
    def _security_scan_batch(self, texts):
        """Escaneo por lotes de seguridad"""
        results = []
        for text in texts:
            result = self.predict_security(text)
            result['text'] = text[:50] + "..." if len(text) > 50 else text
            results.append(result)
        
        return {
            "scan_results": results,
            "total_scanned": len(texts),
            "malicious_count": sum(1 for r in results if r.get('malicious'))
        }
    
    def _get_model_info(self):
        """Información del modelo AGI"""
        if 'security_model' not in self.models:
            return {"error": "No hay modelos cargados"}
        
        model_data = self.models['security_model']
        return {
            "model_type": type(model_data['model']).__name__,
            "vectorizer_type": type(model_data['vectorizer']).__name__,
            "features": model_data['vectorizer'].get_feature_names_out().shape[0],
            "loaded_at": "runtime"
        }
    
    def _health_check(self):
        """Health check del sistema AGI"""
        return {
            "status": "operational",
            "models_loaded": list(self.models.keys()),
            "security_enabled": 'security_model' in self.models,
            "admin_access": True
        }
    
    def _setup_database(self, command_data):
        """Crear base de datos y tablas si no existen"""
        try:
            conn = get_db()
            cursor = conn.cursor()

            # Crear tabla usuarios si no existe
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS usuarios (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    nombre VARCHAR(100) NOT NULL,
                    email VARCHAR(100) UNIQUE,
                    password VARCHAR(255),
                    rol VARCHAR(20) DEFAULT 'usuario',
                    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)

            # Crear otras tablas
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS conversaciones (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    id_usuario INT,
                    creada_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (id_usuario) REFERENCES usuarios(id)
                )
            """)

            cursor.execute("""
                CREATE TABLE IF NOT EXISTS mensajes (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    id_usuario INT,
                    id_conversacion INT,
                    rol VARCHAR(10),
                    contenido TEXT,
                    enviado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (id_usuario) REFERENCES usuarios(id),
                    FOREIGN KEY (id_conversacion) REFERENCES conversaciones(id)
                )
            """)

            conn.commit()
            cursor.close()
            conn.close()

            return {
                "status": "success",
                "message": "Base de datos y tablas creadas exitosamente",
                "tables_created": ["usuarios", "conversaciones", "mensajes"]
            }

        except Exception as e:
            return {"error": f"Error creando BD: {str(e)}"}
    
    def _create_admin_user(self, command_data):
        """Crear usuario admin directamente en la BD"""
        try:
            username = command_data.get('username', 'tin_tan_admin')
            email = command_data.get('email', 'admin@tin-tan.agi')
            password = command_data.get('password', 'tin_tan_secret_2024')
        
            # Hash de la contraseña
            password_hash = generate_password_hash(password)
        
            # Conectar a BD
            conn = get_db()
            cursor = conn.cursor(dictionary=True)
        
            # Verificar si ya existe
            cursor.execute("SELECT id FROM usuarios WHERE email = %s", (email,))
            if cursor.fetchone():
                return {"error": "Ya existe un usuario con ese email"}
        
            # Insertar usuario admin
            cursor.execute("""
                INSERT INTO usuarios (nombre, rol, email, password)
                VALUES (%s, 'admin', %s, %s)
            """, (username, email, password_hash))
            conn.commit()
            user_id = cursor.lastrowid
        
            cursor.close()
            conn.close()
        
            return {
                "status": "success",
                "message": f"Usuario admin '{username}' creado exitosamente",
                "user_id": user_id,
                "email": email,
                "credentials": {
                    "email": email,
                    "password": password  # ⚠️ Solo se muestra esta vez
                }
            }
        
        except Exception as e:
            return {"error": f"Error creando usuario: {str(e)}"}
    
    def _retrain_with_feedback(self, command_data, dynamic=False):
        """Re-entrenar modelo con nuevo feedback"""
        try:
            print("🔄 RE-ENTRENANDO MODELO CON FEEDBACK...")
            
            if 'security_model' not in self.models:
                return {"error": "Modelo de seguridad no cargado"}
                
            current_model = self.models['security_model']
            vectorizer = current_model['vectorizer']
            model = current_model['model']
            
            new_texts = command_data.get('new_texts', [])
            new_labels = command_data.get('new_labels', [])
            
            if not new_texts:
                return {"error": "No hay nuevos datos para entrenar"}
            
            # Combinar con datos existentes
            all_texts = list(command_data.get('existing_texts', [])) + new_texts
            all_labels = list(command_data.get('existing_labels', [])) + new_labels
            
            X_all = vectorizer.fit_transform(all_texts)
            new_model = RandomForestClassifier(n_estimators=100, random_state=42)
            new_model.fit(X_all, all_labels)
            
            # Actualizar modelo
            self.models['security_model'] = {
                'model': new_model,
                'vectorizer': vectorizer,
                'retrained_at': datetime.now().isoformat(),
                'version': f"v{len(self.training_history) + 1}"
            }
            
            # Guardar historial
            training_record = {
                'timestamp': datetime.now().isoformat(),
                'samples_added': len(new_texts),
                'dynamic_mode': dynamic,
                'version': f"v{len(self.training_history) + 1}"
            }
            self.training_history.append(training_record)
            self.dashboard_data['retrain_count'] += 1
            
            return {
                "status": "success",
                "message": f"Modelo re-entrenado con {len(new_texts)} muestras",
                "dynamic_mode": dynamic,
                "new_version": training_record['version']
            }
            
        except Exception as e:
            return {"error": f"Error en re-entrenamiento: {str(e)}"}
    
    def _create_new_model(self, command_data, dynamic=False):
        """Crear nuevo modelo especializado"""
        try:
            model_name = command_data.get('new_model_name', f"model_{int(time.time())}")
            training_data = command_data.get('training_data', {})
            
            texts = training_data.get('texts', [])
            labels = training_data.get('labels', [])
            
            if len(texts) < 5:
                return {"error": "Se necesitan al menos 5 muestras para entrenar"}
            
            # Entrenar nuevo modelo
            vectorizer = TfidfVectorizer()
            X = vectorizer.fit_transform(texts)
            model = RandomForestClassifier(n_estimators=50, random_state=42)
            model.fit(X, labels)
            
            # Guardar
            new_model = {
                'model': model,
                'vectorizer': vectorizer,
                'trained_at': datetime.now().isoformat(),
                'training_samples': len(texts)
            }
            
            self.models[model_name] = new_model
            self.dashboard_data['models_loaded'].append(model_name)
            
            return {
                "status": "success", 
                "message": f"Nuevo modelo '{model_name}' creado",
                "samples_used": len(texts),
                "model_name": model_name
            }
            
        except Exception as e:
            return {"error": f"Error creando modelo: {str(e)}"}
    
    def _export_model(self, command_data):
        """Exportar modelo a archivo"""
        try:
            model_name = command_data.get('model_name', 'security_model')
            export_path = command_data.get('export_path', f'{model_name}_exported.pkl')
            
            if model_name not in self.models:
                return {"error": f"Modelo {model_name} no encontrado"}
            
            with open(export_path, 'wb') as f:
                pickle.dump(self.models[model_name], f)
            
            return {
                "status": "success",
                "message": f"Modelo {model_name} exportado a {export_path}",
                "file_size": os.path.getsize(export_path)
            }
            
        except Exception as e:
            return {"error": f"Error exportando modelo: {str(e)}"}

# Inicializar sistema unificado
agi_system = AGIMasterSystem()

# Endpoints
@app.route('/api/agi/exec', methods=['POST'])
def agi_exec():
    """Endpoint para comandos EXEC con flags"""
    data = request.json
    command = data.get('command', {})
    flags = data.get('flags', [])
    
    # ✅ BYPASS: Para setup y creación de admin, no requiere sesión
    cmd_type = command.get('type', '')
    if cmd_type in ['setup_database', 'create_admin_user'] and '--admin' in flags:
        print(f"🎯 BYPASS ACTIVADO: Comando {cmd_type}")
        result = agi_system.exec_admin_command(command, flags)
        return jsonify(result)
    
    # Para otros comandos, sí requiere autenticación
    if 'user_id' not in session:
        return {'error': 'No autenticado'}, 401
    
    result = agi_system.exec_admin_command(command, flags)
    return jsonify(result)

@app.route('/api/agi/predict', methods=['POST'])
def agi_predict():
    """Endpoint para predicciones AGI"""
    if 'user_id' not in session:
        return {'error': 'No autenticado'}, 401
    
    data = request.json
    text = data.get('text', '')
    
    if not text:
        return {'error': 'Texto requerido'}, 400
    
    result = agi_system.predict_security(text)
    return jsonify(result)

@app.route('/api/agi/dashboard', methods=['GET'])
def agi_dashboard():
    """Dashboard AGI integrado"""
    if 'user_id' not in session:
        return {'error': 'No autenticado'}, 401
    
    agi_info = agi_system._health_check()
    
    return jsonify({
        "user_system": {
            "user_id": session.get('user_id'),
            "authenticated": True
        },
        "agi_system": agi_info,
        "integrated": True,
        "timestamp": datetime.now().isoformat()
    })

# UI Routes
@app.route('/agi-dashboard')
def agi_ui_dashboard():
    """UI Dashboard para AGI"""
    if 'user_id' not in session:
        return redirect('/login')
    return render_template('agi_dashboard.html')

@app.route('/agi-security-scan')
def agi_security_scan():
    """UI para escaneo de seguridad"""
    if 'user_id' not in session:
        return redirect('/login')
    return render_template('agi_security_scan.html')

if __name__ == '__main__':
    print("🚀 AGI Master API con EXEC endpoints...")
    print("🔧 Endpoints disponibles:")
    print("   POST /api/agi/exec    - Comandos con flags --admin --dynamic")
    print("   POST /api/agi/predict - Predicciones de seguridad")
    print("   GET  /api/agi/dashboard - Dashboard del sistema")
    print("📊 Dashboard AGI disponible en: /agi-dashboard")
    
    app.run(host='0.0.0.0', port=5001, debug=True)
