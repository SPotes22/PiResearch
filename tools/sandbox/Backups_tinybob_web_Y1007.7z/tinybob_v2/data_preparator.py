# La arañita va a Kaggle y trae la "comida" (datasets)
# Luego la corta en pedacitos pequeños (arrays numpy)
# Para que la AGI pueda digerirla fácilmente
# data_preparator.py
import pandas as pd
import numpy as np
from datasets import load_dataset
import kagglehub

def preparar_comidita_kaggle():
    """Prepara datasets de Kaggle en arrays numpy listos para CNNs"""
    print("🍎 BUSCANDO COMIDITA EN KAGGLE...")

    # Ejemplo: Dataset de seguridad (como tu AutoPipeline)
    dataset = load_dataset("csv", data_files="tu_dataset_seguridad.csv")

    print("🔪 CORTANDO EN PEDACITOS...")
    # Convertir a arrays numpy para CNNs
    textos = np.array(dataset['train']['text'])
    labels = np.array(dataset['train']['label'])

    # Preparar para transformers (embeddings)
    arrays_preparados = {
        'textos': textos,
        'labels': labels,
        'vocabulario': list(set(' '.join(textos).split())),
        'estadisticas': {
            'total_muestras': len(textos),
            'clases': len(set(labels)),
            'tamano_vocabulario': len(set(' '.join(textos).split()))
        }
    }

    print(f"✅ COMIDITA PREPARADA: {len(textos)} muestras")
    return arrays_preparados

if __name__ == "__main__":
    comidita = preparar_comidita_kaggle()
    np.save('comidita_preparada.npy', comidita)
