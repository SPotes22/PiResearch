# Esto es como tener TODAS las piezas de Lego necesarias
# La arañita instala: numpy, transformers, tensorflow, pandas, scikit-learn
# ¡Para que no te falte NINGUNA pieza!
# requirements_installer.py
import subprocess
import sys

def instalar_todo():
    """Instala el 100% de las librerías que necesitas"""
    librerias = [
        'numpy', 'pandas', 'scikit-learn', 'tensorflow',
        'torch', 'transformers', 'datasets', 'kaggle',
        'matplotlib', 'seaborn', 'jupyter', 'notebook'
    ]

    print("🧩 CONSEGUYENDO TODAS LAS PIEZAS LEGO...")
    for lib in librerias:
        try:
            subprocess.check_call([sys.executable, '-m', 'pip', 'install', lib])
            print(f"✅ {lib} - LISTO")
        except:
            print(f"⚠️  {lib} - ya estaba")

    print("🎉 ¡TODAS LAS PIEZAS LEGO LISTAS!")

if __name__ == "__main__":
    instalar_todo()
