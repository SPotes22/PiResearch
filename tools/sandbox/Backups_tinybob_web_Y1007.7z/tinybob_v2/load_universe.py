import numpy as np
# Cargar sistema pre-construido
matrix = np.load('semantic_universe_matrix.npy')
with open('semantic_system_metadata.json') as f:
    metadata = json.load(f)

print(f"✅ Sistema cargado: {len(metadata['elements'])} conceptos")
# Usar directamente
from semantic_ai_system import SemanticAISystem
ai = SemanticAISystem()
ai.semantic_matrix = matrix

result = ai.semantic_search("machine learning")
print(result['top_results'][0])
