# transformer_trainer_fixed.py
import torch
from transformers import AutoTokenizer, AutoModel
import numpy as np

def entrenar_agi_transformer_fixed():
    print("🧠 ENTRENANDO CON PYTORCH (COMPATIBLE)...")
    
    # Usar PyTorch en lugar de TensorFlow
    tokenizer = AutoTokenizer.from_pretrained("distilbert-base-uncased")  # Modelo más liviano
    model = AutoModel.from_pretrained("distilbert-base-uncased")
    
    # Verificar que funciona
    print("✅ PyTorch cargado - probando inferencia...")
    inputs = tokenizer("Hello world", return_tensors="pt", padding=True, truncation=True)
    
    with torch.no_grad():
        outputs = model(**inputs)
    
    print("🎯 TRANSFORMER FUNCIONANDO EN CROSTINI")
    return model, tokenizer

# Probar primero
if __name__ == "__main__":
    try:
        model, tokenizer = entrenar_agi_transformer_fixed()
        print("🚀 ¡COMPATIBILIDAD CONFIRMADA!")
    except Exception as e:
        print(f"❌ Error: {e}")
