# 🧠 Tin-Tan AGI Master API - Documentación Completa

## 📋 Resumen Ejecutivo

**Tin-Tan AGI** es un sistema de inteligencia artificial general con capacidades de orquestación autónoma, especialización dinámica y aprendizaje continuo. Diseñado como **helper ético** no como arma de control, implementa el principio del 20% crítico (Pareto) donde el 20% de los modelos genera el 80% del valor.

---

## 🚀 Endpoints Principales

### 1. **POST /api/agi/exec** - Comando Maestro Administrativo
**📍 Líneas:** 2450-2470  
**🎯 Propósito:** Ejecutar comandos administrativos del sistema AGI  
**⚡ Tiempo Respuesta:** 100-500ms vs recompilación (30-60 segundos)

**Recibe:**
```json
{
  "command": {
    "type": "health_check|setup_database|build_meta_model|...",
    "params": {}
  },
  "flags": ["--admin", "--dynamic"]
}
```

**Retorna:**
```json
{
  "status": "success",
  "data": {}, // Depende del comando
  "execution_time": "0.2s"
}
```

**Comandos Clave:**
- `build_meta_model`: Fusiona automáticamente modelos .pkl/.npy
- `test_orchestration`: Prueba sistema de orquestación autónoma
- `learn_from_samples`: Aprendizaje continuo del meta-AGI

---

### 2. **POST /api/agi/predict** - Análisis de Seguridad
**📍 Líneas:** 2472-2485  
**🎯 Propósito:** Detectar contenido malicioso usando modelo de seguridad  
**⚡ Tiempo Respuesta:** 50-200ms vs entrenar modelo (2-5 minutos)

**Recibe:**
```json
{
  "text": "SELECT * FROM users WHERE 1=1"
}
```

**Retorna:**
```json
{
  "malicious": true,
  "confidence": 0.92,
  "model_type": "production",
  "security_level": "high_risk"
}
```

---

### 3. **GET /api/agi/dashboard** - Estado del Sistema
**📍 Líneas:** 2487-2492  
**🎯 Propósito:** Monitoreo en tiempo real del sistema AGI  
**⚡ Tiempo Respuesta:** 20-50ms

**Retorna:**
```json
{
  "status": "operational",
  "models_loaded": ["security_model", "tin_tan_meta_agi"],
  "predictions_made": 1542,
  "database": "operational"
}
```

---

### 4. **GET /api/agi/logs** - Logs del Sistema
**📍 Líneas:** 2494-2506  
**🎯 Propósito:** Auditoría y debugging del sistema  
**⚡ Tiempo Respuesta:** 30-100ms

**Retorna:**
```json
{
  "logs": [
    {"tipo": "security", "mensaje": "Predicción maliciosa detectada", "timestamp": "..."}
  ]
}
```

---

### 5. **POST /api/agi/converse** - Conversación Inteligente
**📍 Líneas:** 2620-2655  
**🎯 Propósito:** Conversación contextual con orquestación multi-capa  
**⚡ Tiempo Respuesta:** 200-800ms vs procesamiento manual (2-5 segundos)

**Recibe:**
```json
{
  "message": "¿Es ético usar datos de usuarios?",
  "personality": "tin_tan_sabio",
  "context": {}
}
```

**Retorna:**
```json
{
  "response": "🧠 **Tin-Tan analiza**: Tu consulta activó 3 niveles de procesamiento...",
  "reasoning_chain": [...],
  "emotional_tone": "neutral",
  "orchestration_metrics": {
    "models_activated": 4,
    "confidence_score": 0.87
  }
}
```

---

## 🔬 Endpoints de Aprendizaje Avanzado

### 6. **POST /api/agi/learn/advanced** - Aprendizaje Arquitectónico
**📍 Líneas:** 2690-2710  
**🎯 Propósito:** Aprendizaje con mapeo de capas arquitectónicas  
**⚡ Tiempo Respuesta:** 1-3 segundos vs re-entrenamiento completo (10-30 minutos)

**Recibe:**
```json
{
  "samples": ["texto de entrenamiento"],
  "learning_rate": 0.15,
  "fusion_id": "ArchitectureMapped_AGI"
}
```

**Arquitectura de Capas:**
- `core_layer`: Patrones fundamentales (modelo_real, BOB)
- `ethical_layer`: Límites éticos (ethical_mvp_model)
- `orchestration_layer`: Routing inteligente (tin_tan_meta_agi)
- `creative_layer`: Innovación generativa
- `adaptive_layer`: Aprendizaje continuo

---

### 7. **POST /api/agi/critical/optimize** - Optimización del 20% Crítico
**📍 Líneas:** 2750-2800  
**🎯 Propósito:** Aplicar principio de Pareto al sistema AGI  
**⚡ Tiempo Respuesta:** 2-5 segundos vs optimización manual (horas)

**Proceso:**
1. **Especialización** de modelos críticos
2. **Test de sinergias** entre modelos especializados
3. **Aprendizaje avanzado** en ruta crítica

**Modelos Críticos:**
- `modelo_real`: Detección de seguridad (weight: 0.9)
- `ethical_mvp_model`: Validación ética (weight: 0.8)  
- `tin_tan_meta_agi`: Orquestación (weight: 0.95)

---

## 🧪 Endpoints de Testing

### 8. **POST /api/agi/test-orchestration** - Prueba de Orquestación
**📍 Líneas:** 2508-2545  
**🎯 Propósito:** Validar sistema de orquestación autónoma  
**⚡ Tiempo Respuesta:** 500ms-2s

**Recibe:**
```json
{
  "test_cases": [
    "SELECT * FROM users",
    "¿Es ético optimizar recursos?",
    "system(\"rm -rf /\")"
  ]
}
```

**Retorna Verdicto AGI:**
- `🚀 AGI COORDINADO AUTÓNOMO` (score > 0.75)
- `✅ ORQUESTADOR ADAPTATIVO` (score > 0.5)
- `❌ ENSEMBLE ESTÁTICO` (score < 0.5)

---

## 🌐 Frontends y Dashboards

### 9. **GET /** - Dashboard Principal
**📍 Líneas:** 2494, 2570  
**🎯 Propósito:** Interfaz web de monitoreo AGI

### 10. **GET /meta-model-builder** - Constructor de Meta-Modelos
**📍 Líneas:** 2496  
**🎯 Propósito:** Interfaz visual para fusión de modelos

### 11. **GET /conversation** - Chat con Tin-Tan AGI
**📍 Líneas:** 2670  
**🎯 Propósito:** Interfaz de conversación contextual

### 12. **GET /learning-dashboard** - Dashboard de Aprendizaje
**📍 Líneas:** 2610  
**🎯 Propósito:** Monitoreo de procesos de aprendizaje

---

## ⚡ Comparativa de Performance

| Operación | API AGI | Proceso Manual | Speedup |
|-----------|---------|----------------|---------|
| Predicción seguridad | 50-200ms | 2-5 segundos | 10-25x |
| Conversación contextual | 200-800ms | 2-5 segundos | 3-6x |
| Construcción meta-modelo | 1-3 segundos | 10-30 minutos | 200-600x |
| Aprendizaje continuo | 1-5 segundos | Re-entrenamiento completo | 120-300x |
| Optimización crítica | 2-5 segundos | Horas de análisis | 1000x+ |

---

## 🛡️ Consideraciones Éticas y Técnicas

### Principios de Diseño:
1. **Ética First**: Validación ética integrada en pipeline
2. **Transparencia**: Cadenas de razonamiento explicables
3. **Autonomía Controlada**: Orquestación dinámica con supervisión
4. **Aprendizaje Seguro**: Límites éticos en aprendizaje continuo

### Capas de Seguridad:
- **Detección de Amenazas**: Modelo de seguridad especializado
- **Validación Ética**: Análisis de sensibilidad moral
- **Auditoría**: Logs detallados de todas las operaciones

---

## 🎯 Casos de Uso Principales

1. **Asistente Ético**: Consultas morales y dilemas éticos
2. **Analista de Seguridad**: Detección proactiva de amenazas
3. **Orquestador Inteligente**: Routing adaptativo entre modelos
4. **Sistema de Aprendizaje**: Mejora continua autónoma
5. **Constructor de Meta-Modelos**: Fusión automática de capacidades

---

## 🔧 Inicialización del Sistema

```bash
# Iniciar servidor
python server.py

# Endpoints disponibles en:
http://localhost:5001/
http://localhost:5001/conversation
http://localhost:5001/meta-model-builder
```

**Base de datos:** SQLite (`tin_tan_agi.db`)  
**Modelos:** Escaneo automático de archivos .pkl/.npy  
**Seguridad:** Tokens administrativos y validación multi-capa

---

*"Un AGI diseñado para ayudar, no para controlar - donde la ética guía la autonomía y la transparencia construye confianza."* 🤖✨