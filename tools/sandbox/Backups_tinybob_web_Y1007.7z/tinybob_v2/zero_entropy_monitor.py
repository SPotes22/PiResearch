# zero_entropy_monitor.py
import time
import subprocess
import psutil
from datetime import datetime

class ZeroEntropyMonitor:
    def __init__(self):
        self.process_name = "zero_entro_shot"
        self.admin_mode = True
        self.dynamic_mode = True
        
    def check_process_status(self):
        """Verificar si el proceso zero_entropy sigue ejecutándose"""
        print("🔍 BUSCANDO PROCESO ZERO_ENTROPY...")
        
        for proc in psutil.process_iter(['pid', 'name', 'status']):
            if self.process_name in proc.info['name'].lower():
                return {
                    'status': 'STILL_WORKING',
                    'pid': proc.info['pid'],
                    'process_status': proc.info['status'],
                    'cpu_percent': psutil.cpu_percent(interval=1),
                    'memory_usage': psutil.virtual_memory().percent,
                    'timestamp': datetime.now().isoformat()
                }
        
        return {'status': 'PROCESS_NOT_FOUND', 'timestamp': datetime.now().isoformat()}

# EJECUTAR DIAGNÓSTICO
monitor = ZeroEntropyMonitor()
estado = monitor.check_process_status()

print(f"🎯 RESULTADO: {estado['status']}")
if estado['status'] == 'STILL_WORKING':
    print(f"   PID: {estado['pid']}")
    print(f"   CPU: {estado['cpu_percent']}%")
    print(f"   RAM: {estado['memory_usage']}%")
    print("   ✅ CERO-ENTROPÍA ACTIVA - OPTIMIZANDO...")
