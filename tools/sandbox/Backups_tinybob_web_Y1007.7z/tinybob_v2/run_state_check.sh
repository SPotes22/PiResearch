# run_state_check.sh (Ejecutable en crostini_linux_container)
# /bin/bash

# REGLAS: Outputs concretos - Solo archivos/código

# --- CONTEXTO INMUTABLE ---
# stack: python/docker/json/markdown
# entorno: crostini_linux_container
export STATE_FILE='tin_tan_state.json'
export PYTHON_ENV='python3'
export EXEC_TIMESTAMP=$(date +%Y%m%d%H%M%S)

echo "🚀 PiTech - Check de Persistencia TAN"

# 1. Asegurar que el archivo de persistencia exista para la prueba
if [ ! -f $STATE_FILE ]; then
    echo "💾 Creando estado inicial: $STATE_FILE"
    echo '{"tan_history": [], "version": "0.9-INIT"}' > $STATE_FILE
fi

# 2. Ejecutar la prueba unitaria del StateManager
# Esto invocará el bloque 'if __name__ == "__main__":' del .py
$PYTHON_ENV state_manager.py

# 3. Comprobar que el archivo se haya actualizado
LAST_UPDATE=$(grep 'VALIDATION-PING' $STATE_FILE)

if [ -n "$LAST_UPDATE" ]; then
    echo "✅ Validación de Persistencia OK: El TAN fue registrado."
else
    echo "❌ Error de Validación: El TAN no fue registrado en $STATE_FILE."
fi

echo "🏁 Check finalizado. Estado actual en $STATE_FILE."

# Backlog siguiente: Implementar la clase SemanticAISystem, cargando la matriz pre-generada y añadiendo el método de composición lineal.
