# agi_master_api_FIXED.py
from flask import Flask, jsonify, request
from flask_cors import CORS
import pickle
import numpy as np
import time
import threading
import os

app = Flask(__name__)
CORS(app)

class AGIMasterAPI:
    def __init__(self):
        self.models = {}
        self.dashboard_data = {'models_loaded': [], 'predictions_count': 0}
        
    def load_model(self, model_name, model_path):
        """Cargar modelo con verificación robusta"""
        try:
            print(f"🔄 Intentando cargar: {model_path}")
            
            # Verificar que el archivo existe
            if not os.path.exists(model_path):
                print(f"❌ Archivo no existe: {model_path}")
                return False
            
            with open(model_path, 'rb') as f:
                model_data = pickle.load(f)
            
            # Verificar estructura del modelo
            if not isinstance(model_data, dict):
                print(f"❌ Formato inválido, esperado dict, obtenido: {type(model_data)}")
                return False
                
            if 'model' not in model_data or 'vectorizer' not in model_data:
                print(f"❌ Keys faltantes: {list(model_data.keys())}")
                return False
            
            self.models[model_name] = model_data
            self.dashboard_data['models_loaded'].append(model_name)
            print(f"✅ {model_name} cargado exitosamente!")
            return True
            
        except Exception as e:
            print(f"❌ Error cargando {model_name}: {e}")
            return False
    
    def predict(self, model_name, input_text, flags=None):
        """Predecir con manejo robusto de errores"""
        if model_name not in self.models:
            return {"error": f"Modelo '{model_name}' no encontrado. Modelos disponibles: {list(self.models.keys())}"}
        
        try:
            model_data = self.models[model_name]
            X = model_data['vectorizer'].transform([input_text])
            probabilities = model_data['model'].predict_proba(X)[0]
            prediction = model_data['model'].predict(X)[0]
            confidence = max(probabilities)
            
            # Log
            self.dashboard_data['predictions_count'] += 1
            
            return {
                'prediction': int(prediction),
                'confidence': float(confidence),
                'malicious': bool(prediction),
                'status': 'success',
                'model_used': model_name
            }
            
        except Exception as e:
            return {"error": f"Error en predicción: {str(e)}"}

# Inicializar
agi_system = AGIMasterAPI()

def initialize_system():
    """Cargar modelo con retry"""
    time.sleep(2)
    print("🚀 Inicializando sistema...")
    
    # Intentar cargar el modelo
    success = agi_system.load_model('security_model', 'modelo_real.pkl')
    
    if not success:
        print("❌ No se pudo cargar modelo_real.pkl, intentando crear uno...")
        # Crear modelo de emergencia
        from sklearn.ensemble import RandomForestClassifier
        from sklearn.feature_extraction.text import TfidfVectorizer
        
        # Datos de ejemplo
        texts = ["normal", "SELECT * FROM users", "hola", "admin OR 1=1"]
        labels = [0, 1, 0, 1]
        
        vectorizer = TfidfVectorizer()
        X = vectorizer.fit_transform(texts)
        model = RandomForestClassifier()
        model.fit(X, labels)
        
        emergency_model = {'model': model, 'vectorizer': vectorizer}
        with open('modelo_real.pkl', 'wb') as f:
            pickle.dump(emergency_model, f)
        
        print("✅ Modelo de emergencia creado!")
        agi_system.load_model('security_model', 'modelo_real.pkl')

# Rutas
@app.route('/api/dashboard')
def api_dashboard():
    return jsonify(agi_system.dashboard_data)

@app.route('/api/predict', methods=['POST'])
def api_predict():
    data = request.json
    result = agi_system.predict(data.get('model', 'security_model'), data['text'])
    return jsonify(result)

@app.route('/')
def dashboard():
    return """
    <html><body>
        <h1>🧠 AGI Dashboard</h1>
        <div id="status">Cargando...</div>
        <script>
            fetch('/api/dashboard').then(r => r.json()).then(data => {
                document.getElementById('status').innerHTML = 
                    `Modelos: ${data.models_loaded.join(', ') || 'NINGUNO'}<br>
                     Predicciones: ${data.predictions_count}`;
            });
        </script>
    </body></html>
    """

# Iniciar
threading.Thread(target=initialize_system, daemon=True).start()

if __name__ == '__main__':
    print("🚀 Iniciando AGI Master API...")
    app.run(host='0.0.0.0', port=5000, debug=True)
