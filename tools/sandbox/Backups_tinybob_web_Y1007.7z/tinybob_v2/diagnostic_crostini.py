# diagnostic_crostini.py
import subprocess
import sys

print("🔍 DIAGNÓSTICO CROSTINI:")

# 1. Verificar arquitectura
result = subprocess.run(["lscpu"], capture_output=True, text=True)
print("CPU INFO:")
print(result.stdout[:500])

# 2. Verificar instrucciones soportadas
try:
    import cpuinfo
    info = cpuinfo.get_cpu_info()
    print(f"🚀 CPU: {info['brand_raw']}")
    print(f"📋 Instructions: {info['flags']}")
except:
    print("⚠️  No se pudo obtener info detallada de CPU")

# 3. Probar carga básica
try:
    import torch
    print("✅ PyTorch compatible")
except Exception as e:
    print(f"❌ PyTorch error: {e}")

try:
    import tensorflow as tf
    print("✅ TensorFlow compatible") 
except Exception as e:
    print(f"❌ TensorFlow error: {e}")
