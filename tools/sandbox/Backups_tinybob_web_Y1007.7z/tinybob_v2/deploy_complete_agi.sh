#!/bin/bash
# deploy_complete_agi.sh

echo "🧠 DESPLIEGUE COMPLETO SISTEMA AGI TIN-TAN"
echo "=========================================="

# Verificar Python y dependencias
echo "🔍 Verificando entorno..."
python3 --version
pip --version

# Instalar dependencias completas
echo "📦 Instalando dependencias AGI..."
pip install numpy sentence-transformers scikit-learn aiohttp requests

# Crear estructura de directorios
mkdir -p agi_complete_output
mkdir -p output

# Ejecutar despliegue completo
echo "🚀 Ejecutando despliegue completo..."
python3 agi_complete_system.py

# Verificar todos los componentes
echo ""
echo "📁 VERIFICANDO COMPONENTES DESPLEGADOS:"
find agi_complete_output -name "*.json" -o -name "*.npy" | while read file; do
    component=$(basename "$file" | cut -d'.' -f1)
    size=$(du -h "$file" | cut -f1)
    echo "   ✅ $component ($size)"
done

echo ""
echo "🎯 EJECUTANDO SCRIPTS DE VALIDACIÓN:"
echo "   • Sistema ético: python init_ethics_system.sh"
echo "   • Training loop: python run_training_loop.sh" 
echo "   • Convergencia: python run_convergence_test.sh"
echo "   • MVP Executor: python run_agi_executor.sh"

echo ""
echo "🚀 SISTEMA AGI COMPLETO DESPLEGADO"
echo "   Componentes: 7 módulos operativos"
echo "   Capacidades: Ética + Aprendizaje + Comunicación"
echo "   Entorno: Web4 ready con filosofía 81/20"
