# FIX_data_preparator.py
import pandas as pd
import numpy as np
import os

def crear_dataset_automatico():
    """Crear dataset de seguridad automáticamente"""
    print("🛠️ CREANDO DATASET DE SEGURIDAD...")
    
    # Datos de ejemplo (como en AutoPipeline)
    datos = {
        'text': [
            # Ataques
            "admin' OR '1'='1'--", 
            "<script>alert('XSS')</script>",
            "../../../etc/passwd",
            "| cat /etc/passwd",
            # Normales
            "/api/users/list?page=1",
            "user@example.com", 
            "/static/css/main.css",
            "Hola mundo normal"
        ],
        'label': [1, 1, 1, 1, 0, 0, 0, 0]  # 1=ataque, 0=normal
    }
    
    df = pd.DataFrame(datos)
    df.to_csv('tu_dataset_seguridad.csv', index=False)
    print(f"✅ DATASET CREADO: {len(df)} muestras")
    return df

# Reemplazar la función problemática
def preparar_comidita_kaggle_fixed():
    """Versión corregida que crea datos si no existen"""
    if not os.path.exists('tu_dataset_seguridad.csv'):
        crear_dataset_automatico()
    
    # Ahora cargar el dataset creado
    from datasets import load_dataset
    dataset = load_dataset("csv", data_files="tu_dataset_seguridad.csv")
    
    print("🔪 PREPARANDO DATOS...")
    textos = np.array(dataset['train']['text'])
    labels = np.array(dataset['train']['label'])
    
    return {
        'textos': textos,
        'labels': labels,
        'vocabulario': list(set(' '.join(textos).split()))
    }

# EJECUTAR FIX
if __name__ == "__main__":
    comidita = preparar_comidita_kaggle_fixed()
    print(f"🎯 DATOS LISTOS: {len(comidita['textos'])} muestras")
