# La arañita usa los bloques Lego (librerías) 
# Y la comidita preparada (datasets de Kaggle)
# Para enseñarle a la AGI a pensar como transformer
# ¡Y guarda lo aprendido en un .pkl (como una mochila mágica)!
# transformer_trainer.py
import numpy as np
import tensorflow as tf
from transformers import AutoTokenizer, TFAutoModel
import pickle

def entrenar_agi_transformer():
    """Enseña a la AGI usando transformers y guarda en .pkl"""
    print("🧠 LA AGI ESTÁ APRENDIENDO...")

    # Cargar la comidita preparada
    comidita = np.load('comidita_preparada.npy', allow_pickle=True).item()

    # Usar transformer pre-entrenado
    tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")
    model = TFAutoModel.from_pretrained("bert-base-uncased")

    print("📚 PROCESANDO TEXTOS...")
    # Tokenizar textos
    inputs = tokenizer(
        comidita['textos'].tolist(),
        padding=True,
        truncation=True,
        return_tensors="tf",
        max_length=128
    )

    print("🎯 ENTRENANDO TRANSFORMER...")
    # Generar embeddings (representaciones numéricas)
    outputs = model(inputs)
    embeddings = outputs.last_hidden_state[:, 0, :].numpy()

    # Crear modelo final
    modelo_final = tf.keras.Sequential([
        tf.keras.layers.Dense(128, activation='relu'),
        tf.keras.layers.Dropout(0.3),
        tf.keras.layers.Dense(64, activation='relu'),
        tf.keras.layers.Dense(len(set(comidita['labels'])), activation='softmax')
    ])

    modelo_final.compile(
        optimizer='adam',
        loss='sparse_categorical_crossentropy',
        metrics=['accuracy']
    )

    # Entrenar
    historia = modelo_final.fit(
        embeddings, comidita['labels'],
        epochs=5, batch_size=32, validation_split=0.2
    )

    # Guardar TODO en .pkl
    paquete_magico = {
        'tokenizer': tokenizer,
        'transformer_model': model,
        'clasificador': modelo_final,
        'embeddings': embeddings,
        'accuracy_final': historia.history['accuracy'][-1],
        'datos_entrenamiento': comidita
    }

    with open('agi_transformer_magico.pkl', 'wb') as f:
        pickle.dump(paquete_magico, f)

    print(f"✅ AGI ENSEÑADA - Accuracy: {historia.history['accuracy'][-1]:.2%}")
    return paquete_magico

if __name__ == "__main__":
    agi_entrenada = entrenar_agi_transformer()
