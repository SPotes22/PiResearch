# agi_master_api_EXEC.py
from flask import Flask, jsonify, request
from flask_cors import CORS
import pickle
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
import threading
import time
import os
import json
from datetime import datetime

app = Flask(__name__)
CORS(app)
# Tu código existente SIN modificaciones
from flask import Flask, request, render_template, session, redirect, flash
import chatbot_core as chat_core
import mysql.connector
from datetime import datetime
from flask_session import Session
from werkzeug.security import generate_password_hash, check_password_hash
import os
import requests

# Configuración de la aplicación Flask (EXISTENTE)
#app = Flask(__name__)
app.secret_key = 'super-secret-key1'
app.config['SESSION_TYPE'] = 'filesystem'
Session(app)




class AGIMasterAPI:
    def __init__(self):
        self.models = {}
        self.training_history = []
        self.dashboard_data = {'models_loaded': [], 'predictions_count': 0, 'retrain_count': 0}
        self.admin_tokens = {"local_admin_2024"}  # Solo funciona en local
        self.load_model('security_model', 'modelo_real.pkl')
    
    def load_model(self, model_name, model_path):
        """Cargar modelo con verificación robusta"""
        try:
            print(f"🔄 Intentando cargar: {model_path}")
            
            # Verificar que el archivo existe
            if not os.path.exists(model_path):
                print(f"❌ Archivo no existe: {model_path}")
                return False
            
            with open(model_path, 'rb') as f:
                model_data = pickle.load(f)
            
            # Verificar estructura del modelo
            if not isinstance(model_data, dict):
                print(f"❌ Formato inválido, esperado dict, obtenido: {type(model_data)}")
                return False
                
            if 'model' not in model_data or 'vectorizer' not in model_data:
                print(f"❌ Keys faltantes: {list(model_data.keys())}")
                return False
            
            self.models[model_name] = model_data
            self.dashboard_data['models_loaded'].append(model_name)
            print(f"✅ {model_name} cargado exitosamente!")
            return True
            
        except Exception as e:
            print(f"❌ Error cargando {model_name}: {e}")
            return False
    
    def predict(self, model_name, input_text, flags=None):
        """Predecir con manejo robusto de errores"""
        if model_name not in self.models:
            return {"error": f"Modelo '{model_name}' no encontrado. Modelos disponibles: {list(self.models.keys())}"}
        
        try:
            model_data = self.models[model_name]
            X = model_data['vectorizer'].transform([input_text])
            probabilities = model_data['model'].predict_proba(X)[0]
            prediction = model_data['model'].predict(X)[0]
            confidence = max(probabilities)
            
            # Log
            self.dashboard_data['predictions_count'] += 1
            
            return {
                'prediction': int(prediction),
                'confidence': float(confidence),
                'malicious': bool(prediction),
                'status': 'success',
                'model_used': model_name
            }
            
        except Exception as e:
            return {"error": f"Error en predicción: {str(e)}"}
    
    def exec_retrain(self, command_data, flags):
        """Endpoint EXEC para re-entrenamiento dinámico"""
        print(f"🎯 EJECUTANDO COMANDO EXEC: {command_data}")
        
        # Verificar flag --admin
        if '--admin' in flags:
            if not self._verify_admin_token(command_data.get('admin_token')):
                return {"error": "Admin token inválido. Solo disponible en local."}
        
        # Procesar según tipo de comando
        cmd_type = command_data.get('type', '')
        
        if cmd_type == 'retrain_with_feedback':
            return self._retrain_with_feedback(command_data, '--dynamic' in flags)
        elif cmd_type == 'create_new_model':
            return self._create_new_model(command_data, '--dynamic' in flags)
        elif cmd_type == 'export_model':
            return self._export_model(command_data)
        else:
            return {"error": f"Tipo de comando no reconocido: {cmd_type}"}
    
    def _verify_admin_token(self, token):
        """Verificar que es ejecución local (seguridad)"""
        # En producción, esto verificaría IP local, etc.
        return token in self.admin_tokens
    
    def _retrain_with_feedback(self, command_data, dynamic=False):
        """Re-entrenar modelo con nuevo feedback"""
        try:
            print("🔄 RE-ENTRENANDO MODELO CON FEEDBACK...")
            
            # 1. Cargar modelo actual
            current_model = self.models['security_model']
            vectorizer = current_model['vectorizer']
            model = current_model['model']
            
            # 2. Preparar nuevos datos
            new_texts = command_data.get('new_texts', [])
            new_labels = command_data.get('new_labels', [])
            
            if not new_texts:
                return {"error": "No hay nuevos datos para entrenar"}
            
            # 3. Combinar con datos existentes (si dynamic)
            if dynamic and hasattr(model, 'classes_'):
                # Estrategia dynamic: ajuste incremental
                X_new = vectorizer.transform(new_texts)
                
                # Re-entrenar con datos existentes + nuevos
                if hasattr(model, 'warm_start'):
                    model.warm_start = True
                    model.n_estimators += 10  # Añadir más árboles
                
                model.fit(X_new, new_labels)
            else:
                # Estrategia conservadora: entrenar desde cero
                all_texts = list(command_data.get('existing_texts', [])) + new_texts
                all_labels = list(command_data.get('existing_labels', [])) + new_labels
                
                X_all = vectorizer.fit_transform(all_texts)
                new_model = RandomForestClassifier(n_estimators=100, random_state=42)
                new_model.fit(X_all, all_labels)
                model = new_model
            
            # 4. Actualizar modelo
            self.models['security_model'] = {
                'model': model,
                'vectorizer': vectorizer,
                'retrained_at': datetime.now().isoformat(),
                'version': f"v{len(self.training_history) + 1}"
            }
            
            # 5. Guardar historial
            training_record = {
                'timestamp': datetime.now().isoformat(),
                'samples_added': len(new_texts),
                'dynamic_mode': dynamic,
                'new_accuracy': self._quick_test(model, vectorizer)
            }
            self.training_history.append(training_record)
            self.dashboard_data['retrain_count'] += 1
            
            return {
                "status": "success",
                "message": f"Modelo re-entrenado con {len(new_texts)} muestras",
                "dynamic_mode": dynamic,
                "new_version": training_record['version'],
                "quick_accuracy": training_record['new_accuracy']
            }
            
        except Exception as e:
            return {"error": f"Error en re-entrenamiento: {str(e)}"}
    
    def _create_new_model(self, command_data, dynamic=False):
        """Crear nuevo modelo especializado"""
        try:
            model_name = command_data.get('new_model_name', f"model_{int(time.time())}")
            training_data = command_data.get('training_data', {})
            
            texts = training_data.get('texts', [])
            labels = training_data.get('labels', [])
            
            if len(texts) < 5:
                return {"error": "Se necesitan al menos 5 muestras para entrenar"}
            
            # Entrenar nuevo modelo
            vectorizer = TfidfVectorizer()
            X = vectorizer.fit_transform(texts)
            model = RandomForestClassifier(n_estimators=50, random_state=42)
            model.fit(X, labels)
            
            # Guardar
            new_model = {
                'model': model,
                'vectorizer': vectorizer,
                'trained_at': datetime.now().isoformat(),
                'training_samples': len(texts)
            }
            
            self.models[model_name] = new_model
            self.dashboard_data['models_loaded'].append(model_name)
            
            return {
                "status": "success", 
                "message": f"Nuevo modelo '{model_name}' creado",
                "samples_used": len(texts),
                "model_name": model_name
            }
            
        except Exception as e:
            return {"error": f"Error creando modelo: {str(e)}"}
    
    def _export_model(self, command_data):
        """Exportar modelo a archivo"""
        try:
            model_name = command_data.get('model_name', 'security_model')
            export_path = command_data.get('export_path', f'{model_name}_exported.pkl')
            
            if model_name not in self.models:
                return {"error": f"Modelo {model_name} no encontrado"}
            
            with open(export_path, 'wb') as f:
                pickle.dump(self.models[model_name], f)
            
            return {
                "status": "success",
                "message": f"Modelo {model_name} exportado a {export_path}",
                "file_size": os.path.getsize(export_path)
            }
            
        except Exception as e:
            return {"error": f"Error exportando modelo: {str(e)}"}
    
    def _quick_test(self, model, vectorizer):
        """Test rápido de accuracy"""
        try:
            test_texts = ["normal", "SELECT * FROM users", "hola", "admin OR 1=1"]
            test_labels = [0, 1, 0, 1]
            X_test = vectorizer.transform(test_texts)
            accuracy = model.score(X_test, test_labels)
            return accuracy
        except:
            return 0.0

# Inicializar
agi_system = AGIMasterAPI()

## NUEVO ENDPOINT EXEC
@app.route('/api/agi/exec', methods=['POST'])
def agi_exec():
    """Endpoint para comandos EXEC con flags - CON BYPASS PARA SETUP"""
    data = request.json
    command = data.get('command', {})
    flags = data.get('flags', [])
    
    # ✅ BYPASS: Si es comando de creación de admin, no requiere auth
    if command.get('type') == ( 'setup_database' or 'create_admin_user') and '--admin' in flags:
        print("🎯 BYPASS ACTIVADO: Creación de admin inicial")
        result = agi_system.exec_admin_command(command, flags)
        return jsonify(result)
    elif cmd_type == 'setup_database':  # ✅ NUEVO COMANDO
        return self._setup_database(command_data)
    # ✅ Para otros comandos, sí requiere autenticación normal
    if 'user_id' not in session:
        return {'error': 'No autenticado'}, 401
    
    result = agi_system.exec_admin_command(command, flags)
    return jsonify(result)

# Endpoints existentes
@app.route('/api/dashboard')
def api_dashboard():
    return jsonify(agi_system.dashboard_data)

@app.route('/api/predict', methods=['POST'])
def api_predict():
    data = request.json
    result = agi_system.predict(data.get('model', 'security_model'), data['text'])
    return jsonify(result)


class AGIIntegration:
    def __init__(self):
        self.models = {}
        self.admin_tokens = {"local_admin_2024"}
        self.load_security_model()
    
    def load_security_model(self):
        """Cargar modelo de seguridad automáticamente"""
        try:
            with open('modelo_real.pkl', 'rb') as f:
                self.models['security_model'] = pickle.load(f)
            print("✅ AGI Security Model cargado")
        except Exception as e:
            print(f"⚠️  No se pudo cargar modelo AGI: {e}")
    
    def predict_security(self, text):
        """Predecir si texto es malicioso"""
        if 'security_model' not in self.models:
            return {"error": "Modelo AGI no disponible"}
        
        try:
            model_data = self.models['security_model']
            X = model_data['vectorizer'].transform([text])
            probabilities = model_data['model'].predict_proba(X)[0]
            prediction = model_data['model'].predict(X)[0]
            confidence = max(probabilities)
            
            return {
                'malicious': bool(prediction),
                'confidence': float(confidence),
                'prediction': int(prediction)
            }
        except Exception as e:
            return {"error": str(e)}
    
    def exec_admin_command(self, command_data, flags):
        """Ejecutar comandos admin con flags"""
        # Verificar --admin flag
        if '--admin' in flags and command_data.get('admin_token') not in self.admin_tokens:
            return {"error": "Admin token inválido"}
        
        cmd_type = command_data.get('type', '')
        
        if cmd_type == 'security_scan':
            return self._security_scan_batch(command_data.get('texts', []))
        elif cmd_type == 'model_info':
            return self._get_model_info()
        elif cmd_type == 'health_check':
            return self._health_check()
        # Y añade en exec_admin_command:
        elif cmd_type == 'setup_database':  # ✅ NUEVO COMANDO
            return self._setup_database(command_data)
        else:
            return {"error": f"Comando no reconocido: {cmd_type}"}
    
    def _security_scan_batch(self, texts):
        """Escaneo por lotes de seguridad"""
        results = []
        for text in texts:
            result = self.predict_security(text)
            result['text'] = text[:50] + "..." if len(text) > 50 else text
            results.append(result)
        
        return {
            "scan_results": results,
            "total_scanned": len(texts),
            "malicious_count": sum(1 for r in results if r.get('malicious'))
        }
    
    def _get_model_info(self):
        """Información del modelo AGI"""
        if 'security_model' not in self.models:
            return {"error": "No hay modelos cargados"}
        
        model_data = self.models['security_model']
        return {
            "model_type": type(model_data['model']).__name__,
            "vectorizer_type": type(model_data['vectorizer']).__name__,
            "features": model_data['vectorizer'].get_feature_names_out().shape[0],
            "loaded_at": "runtime"
        }
    
    def _health_check(self):
        """Health check del sistema AGI"""
        return {
            "status": "operational",
            "models_loaded": list(self.models.keys()),
            "security_enabled": 'security_model' in self.models,
            "admin_access": True
        }

    # Añade esto a tu clase AGIIntegration en agi_integration_layer.py

    def exec_admin_command(self, command_data, flags):
        """Ejecutar comandos admin con flags"""
        # Verificar --admin flag
        if '--admin' in flags and command_data.get('admin_token') not in self.admin_tokens:
            return {"error": "Admin token inválido"}
    
        cmd_type = command_data.get('type', '')
    
        if cmd_type == 'security_scan':
            return self._security_scan_batch(command_data.get('texts', []))
        elif cmd_type == 'model_info':
            return self._get_model_info()
        elif cmd_type == 'health_check':
            return self._health_check()
        elif cmd_type == 'create_admin_user':  # ✅ NUEVO COMANDO
            return self._create_admin_user(command_data)
        else:
            return {"error": f"Comando no reconocido: {cmd_type}"}

    def _create_admin_user(self, command_data):
        """Crear usuario admin directamente en la BD"""
        try:
            from werkzeug.security import generate_password_hash
            import mysql.connector
        
            username = command_data.get('username', 'tin_tan_admin')
            email = command_data.get('email', 'admin@tin-tan.agi')
            password = command_data.get('password', 'tin_tan_secret_2024')
        
            # Hash de la contraseña
            password_hash = generate_password_hash(password)
        
            # Conectar a BD (usando tu configuración existente)
            conn = get_db()
            cursor = conn.cursor(dictionary=True)
        
            # Verificar si ya existe
            cursor.execute("SELECT id FROM usuarios WHERE email = %s", (email,))
            if cursor.fetchone():
                return {"error": "Ya existe un usuario con ese email"}
        
            # Insertar usuario admin
            cursor.execute("""
                INSERT INTO usuarios (nombre, rol, email, password)
                VALUES (%s, 'admin', %s, %s)
            """, (username, email, password_hash))
            conn.commit()
            user_id = cursor.lastrowid
        
            cursor.close()
            conn.close()
        
            return {
                "status": "success",
                "message": f"Usuario admin '{username}' creado exitosamente",
                "user_id": user_id,
                "email": email,
                "credentials": {
                    "email": email,
                    "password": password  # ⚠️ Solo se muestra esta vez
                }
            }
        
        except Exception as e:
            return {"error": f"Error creando usuario: {str(e)}"}

# Inicializar integración AGI
agi_system = AGIIntegration()

# =============================================================================
# 🎯 NUEVOS ENDPOINTS - SE AÑADEN SIN MODIFICAR LOS EXISTENTES
# =============================================================================

@app.route('/api/agi/predict', methods=['POST'])
def agi_predict():
    """Nuevo endpoint para predicciones AGI"""
    if 'user_id' not in session:
        return {'error': 'No autenticado'}, 401
    
    data = request.json
    text = data.get('text', '')
    
    if not text:
        return {'error': 'Texto requerido'}, 400
    
    result = agi_system.predict_security(text)
    return jsonify(result)

"""
# legacy login
@app.route('/api/agi/exec', methods=['POST'])
def agi_exec():
    #Nuevo endpoint para comandos EXEC con flags
    if 'user_id' not in session:
        return {'error': 'No autenticado'}, 401
    
    data = request.json
    command = data.get('command', {})
    flags = data.get('flags', [])
    
    result = agi_system.exec_admin_command(command, flags)
    return jsonify(result)
"""

# AÑADE ESTO a tu AGIIntegration - COMANDO PARA CREAR LA BD

def _setup_database(self, command_data):
    """Crear base de datos y tablas si no existen"""
    try:
        import mysql.connector

        conn = get_db()
        cursor = conn.cursor()

        # Crear tabla usuarios si no existe
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS usuarios (
                id INT AUTO_INCREMENT PRIMARY KEY,
                nombre VARCHAR(100) NOT NULL,
                email VARCHAR(100) UNIQUE,
                password VARCHAR(255),
                rol VARCHAR(20) DEFAULT 'usuario',
                creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Crear otras tablas que necesites
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS conversaciones (
                id INT AUTO_INCREMENT PRIMARY KEY,
                id_usuario INT,
                creada_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (id_usuario) REFERENCES usuarios(id)
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS mensajes (
                id INT AUTO_INCREMENT PRIMARY KEY,
                id_usuario INT,
                id_conversacion INT,
                rol VARCHAR(10),
                contenido TEXT,
                enviado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (id_usuario) REFERENCES usuarios(id),
                FOREIGN KEY (id_conversacion) REFERENCES conversaciones(id)
            )
        """)

        conn.commit()
        cursor.close()
        conn.close()

        return {
            "status": "success",
            "message": "Base de datos y tablas creadas exitosamente",
            "tables_created": ["usuarios", "conversaciones", "mensajes"]
        }

    except Exception as e:
        return {"error": f"Error creando BD: {str(e)}"}


@app.route('/api/agi/dashboard', methods=['GET'])
def agi_dashboard():
    """Dashboard AGI integrado"""
    if 'user_id' not in session:
        return {'error': 'No autenticado'}, 401
    
    # Combinar info de tu sistema + AGI
    agi_info = agi_system._health_check()
    
    return jsonify({
        "user_system": {
            "user_id": session.get('user_id'),
            "authenticated": True
        },
        "agi_system": agi_info,
        "integrated": True,
        "timestamp": datetime.now().isoformat()
    })

# =============================================================================
# 🎨 NUEVAS VISTAS UI - SE AÑADEN SIN MODIFICAR LAS EXISTENTES
# =============================================================================

@app.route('/agi-dashboard')
def agi_ui_dashboard():
    """UI Dashboard para AGI"""
    if 'user_id' not in session:
        return redirect('/login')
    
    return render_template('agi_dashboard.html')

@app.route('/agi-security-scan')
def agi_security_scan():
    """UI para escaneo de seguridad"""
    if 'user_id' not in session:
        return redirect('/login')
    
    return render_template('agi_security_scan.html')

# =============================================================================
# 📁 TEMPLATES NUEVOS (agi_dashboard.html, agi_security_scan.html)
# =============================================================================

"""
Crea estos templates en tu carpeta templates/:

1. agi_dashboard.html:
'''
<!DOCTYPE html>
<html>
<head>
    <title>AGI Dashboard</title>
    <style>
        .card { border: 1px solid #ddd; padding: 15px; margin: 10px; border-radius: 5px; }
        .malicious { background: #ffebee; }
        .normal { background: #e8f5e8; }
    </style>
</head>
<body>
    <h1>🧠 AGI Integration Dashboard</h1>
    
    <div class="card">
        <h3>📊 Estado del Sistema</h3>
        <div id="systemStatus">Cargando...</div>
    </div>
    
    <div class="card">
        <h3>🎯 Escaneo de Seguridad</h3>
        <textarea id="scanText" placeholder="Texto a escanear..." rows="3" style="width: 100%;"></textarea>
        <button onclick="scanSecurity()">Escanear Seguridad</button>
        <div id="scanResult"></div>
    </div>
    
    <script>
        function loadSystemStatus() {
            fetch('/api/agi/dashboard')
                .then(r => r.json())
                .then(data => {
                    document.getElementById('systemStatus').innerHTML = `
                        Usuario: ${data.user_system.user_id}<br>
                        Modelos AGI: ${data.agi_system.models_loaded.join(', ')}<br>
                        Estado: ${data.agi_system.status}
                    `;
                });
        }
        
        function scanSecurity() {
            const text = document.getElementById('scanText').value;
            fetch('/api/agi/predict', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({text: text})
            })
            .then(r => r.json())
            .then(result => {
                const cls = result.malicious ? 'malicious' : 'normal';
                const status = result.malicious ? '🚨 MALICIOSO' : '✅ NORMAL';
                document.getElementById('scanResult').innerHTML = `
                    <div class="card ${cls}">
                        <strong>${status}</strong><br>
                        Confianza: ${(result.confidence * 100).toFixed(1)}%<br>
                        Predicción: ${result.prediction}
                    </div>
                `;
            });
        }
        
        loadSystemStatus();
    </script>
</body>
</html>
'''

2. agi_security_scan.html:
'''
<!DOCTYPE html>
<html>
<head>
    <title>Security Scan</title>
</head>
<body>
    <h1>🔒 AGI Security Scanner</h1>
    <p>Interfaz para escaneo por lotes de seguridad...</p>
    <!-- Similar estructura pero para batch scanning -->
</body>
</html>
'''
"""

# =============================================================================
# 🚀 EXTENSIÓN DE TU CHAT EXISTENTE CON AGI
# =============================================================================

# Versión extendida de tu función chat() original
def chat_with_agi_security(question):
    """Extensión de tu chat existente con seguridad AGI"""
    
    # 1. Primero verificar seguridad con AGI
    security_check = agi_system.predict_security(question)
    
    # 2. Si es malicioso con alta confianza, bloquear
    if security_check.get('malicious') and security_check.get('confidence', 0) > 0.8:
        return f"🚫 Mensaje bloqueado por seguridad (confianza: {security_check['confidence']:.1%})"
    
    # 3. Si pasa seguridad, proceder con tu lógica normal
    respuesta_modelo = chat_core.predecir_intencion(question, temp=0.7, verbose=0.34)
    respuesta_api = consultar_php_backend(question)
    
    # 4. Añadir info de seguridad al resultado
    security_note = ""
    if security_check.get('malicious'):
        security_note = f" | ⚠️ Marcado como potencialmente sospechoso"
    
    return f"🧠 Model: {respuesta_modelo}\n🌐 API: {respuesta_api}{security_note}"

# =============================================================================
# ✅ TU CÓDIGO ORIGINAL PERMANECE INTACTO
# =============================================================================

# ... [TODO TU CÓDIGO ORIGINAL AQUÍ, SIN MODIFICACIONES] ...



if __name__ == '__main__':
    print("🚀 AGI Master API con EXEC endpoints...")
    print("🔧 Endpoints disponibles:")
    print("   POST /api/predict    - Predicciones normales")
    print("   POST /api/exec       - Comandos con flags --admin --dynamic")
    print("🚀 Iniciando sistema con integración AGI...")
    print("📊 Dashboard AGI disponible en: /agi-dashboard")
    print("🔧 API AGI disponible en: /api/agi/*")

    app.run(host='0.0.0.0', port=5001, debug=True)  # Puerto diferente
