# transformer_trainer_REAL.py
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
import pandas as pd
import numpy as np
import pickle

def entrenar_modelo_real():
    """Modelo REAL que SÍ funciona en Celeron"""
    print("🎯 ENTRENANDO MODELO REAL (no inventado)...")
    
    # 1. Datos REALES (no inventados)
    datos = pd.DataFrame({
        'texto': [
            "hola mundo normal", "SELECT * FROM users", 
            "script alert xss", "api users list",
            "admin OR 1=1", "password 123", "etc passwd"
        ],
        'label': [0, 1, 1, 0, 1, 0, 1]  # 1=malicioso
    })
    
    # 2. TF-IDF REAL (no transformers inventados)
    vectorizer = TfidfVectorizer()
    X = vectorizer.fit_transform(datos['texto'])
    
    # 3. Modelo REAL (no pytorch inventado)
    model = RandomForestClassifier(n_estimators=50)
    model.fit(X, datos['label'])
    
    # 4. Guardar modelo REAL
    with open('modelo_real.pkl', 'wb') as f:
        pickle.dump({'model': model, 'vectorizer': vectorizer}, f)
    
    print("✅ MODELO REAL CREADO Y GUARDADO")
    return model

# EJECUTAR
if __name__ == "__main__":
    entrenar_modelo_real()
