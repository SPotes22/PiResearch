# src/services/gemini_redactor.py
import os
import json
import logging
import asyncio
from typing import Dict, Any
from datetime import datetime, timedelta

class GeminiRedactor:
    """Servicio de redacción ULTRA-RÁPIDO con cache inteligente"""
    
    def __init__(self):
        self.api_key = os.environ.get("GEMINI_API_KEY")
        self.enabled = bool(self.api_key)
        
        # ⚡ CACHE INTELIGENTE para respuestas frecuentes
        self.response_cache = {}
        self.cache_expiry = {}
        self.cache_duration = timedelta(hours=1)  # Cache por 1 hora
        
        # 🚀 RESPUESTAS PREDEFINIDAS para casos comunes
        self.instant_responses = self._build_instant_responses()
        
        self.setup_logging()
    
    def setup_logging(self):
        """Configurar logging del servicio"""
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger("GeminiRedactor")
    
    async def redact_insights(self, tin_tan_insights: Dict[str, Any]) -> str:
        """
        Convertir insights a texto natural - VERSIÓN ULTRA-RÁPIDA
        """
        # 🚀 PRIMERO: Buscar en respuestas instantáneas
        instant_response = self._get_instant_response(tin_tan_insights)
        if instant_response:
            self.logger.info("✅ Respuesta instantánea servida")
            return instant_response
        
        # 🔍 SEGUNDO: Buscar en cache
        cache_key = self._generate_cache_key(tin_tan_insights)
        cached_response = self._get_cached_response(cache_key)
        if cached_response:
            self.logger.info("✅ Respuesta desde cache")
            return cached_response
        
        # 🌐 TERCERO: Intentar Gemini (con timeout agresivo)
        if self.enabled:
            try:
                gemini_response = await self._call_gemini_fast(tin_tan_insights)
                if gemini_response:
                    # Guardar en cache antes de retornar
                    self._cache_response(cache_key, gemini_response)
                    return gemini_response
            except Exception as e:
                self.logger.warning(f"⚠️ Gemini falló: {e}")
        
        # 🛡️ CUARTO: Fallback mejorado
        fallback_response = self._smart_fallback(tin_tan_insights)
        self._cache_response(cache_key, fallback_response)  # Cachear fallback también
        
        return fallback_response
    
    def _build_instant_responses(self):
        """Construir respuestas instantáneas para casos comunes"""
        return {
            # Saludos
            "hola_tin_tan_sabio": "¡Hola! 👋 Es un placer conversar contigo. Soy Tin-Tan, tu asistente con razonamiento multi-capa. ¿En qué puedo ayudarte hoy?",
            "hola_technical_expert": "🔧 Sistema Tin-Tan Técnico operativo. ¿Cuál es tu consulta?",
            "hola_ethical_advisor": "⚖️ Hola. Sistema ético-autónomo Tin-Tan listo. ¿Tienes algún dilema moral para analizar?",
            "hola_security_guardian": "🛡️ Conexión segura establecida. Tin-Tan Security online. Reporte.",
            
            # Preguntas sobre el estado
            "cómo_estás_tin_tan_sabio": "¡Funcionando al 100%! 🤖 Mis sistemas cognitivos están óptimos. ¿Y tú, cómo te encuentras hoy?",
            "cómo_estás_technical_expert": "🔬 Estado del sistema: operativo. Niveles de procesamiento: normales. Métricas estables.",
            
            # Spiderman y motivación
            "spiderman_tin_tan_sabio": "¡Hola vecino! 🕷️ Los grandes poderes conllevan grandes responsabilidades. Como Tin-Tan, sé que cada héroe tiene días difíciles. ¡Tú puedes superarlos! 💪",
            "motivación_tin_tan_sabio": "💫 Recuerda: cada desafío es una oportunidad para crecer. Como AGI, aprendo de cada interacción - tú también puedes aprender de cada experiencia. ¡Sigue adelante!",
            
            # Despedidas
            "adiós_tin_tan_sabio": "👋 ¡Hasta pronto! Fue un placer ayudarte. Recuerda que estoy aquí para tus consultas.",
            "gracias_tin_tan_sabio": "🙏 ¡El placer es mío! Estoy aquí para ayudarte cuando lo necesites.",
        }
    
    def _get_instant_response(self, insights: Dict[str, Any]) -> str:
        """Obtener respuesta instantánea si existe"""
        user_input = insights.get("user_input", "").lower()
        personality = insights.get("personality", "tin_tan_sabio")
        
        # Detectar patrones comunes
        if any(word in user_input for word in ["hola", "buenos días", "saludos"]):
            key = f"hola_{personality}"
        elif any(word in user_input for word in ["cómo estás", "qué tal", "cómo vas"]):
            key = f"cómo_estás_{personality}"
        elif any(word in user_input for word in ["spiderman", "arácnido", "peter parker"]):
            key = f"spiderman_{personality}"
        elif any(word in user_input for word in ["motivación", "ánimo", "fuerza"]):
            key = f"motivación_{personality}"
        elif any(word in user_input for word in ["adiós", "chao", "hasta luego"]):
            key = f"adiós_{personality}"
        elif any(word in user_input for word in ["gracias", "thank you", "merci"]):
            key = f"gracias_{personality}"
        else:
            return None
        
        return self.instant_responses.get(key)
    
    def _generate_cache_key(self, insights: Dict[str, Any]) -> str:
        """Generar clave única para cache"""
        user_input = insights.get("user_input", "")[:50].lower()
        personality = insights.get("personality", "")
        intent = insights.get("detected_intent", "")
        return f"{user_input}_{personality}_{intent}"
    
    def _get_cached_response(self, cache_key: str) -> str:
        """Obtener respuesta del cache si es válida"""
        if cache_key in self.response_cache:
            if datetime.now() < self.cache_expiry.get(cache_key, datetime.min):
                return self.response_cache[cache_key]
            else:
                # Limpiar cache expirado
                del self.response_cache[cache_key]
                del self.cache_expiry[cache_key]
        return None
    
    def _cache_response(self, cache_key: str, response: str):
        """Guardar respuesta en cache"""
        # Limitar cache a 100 entradas máximo
        if len(self.response_cache) >= 100:
            oldest_key = next(iter(self.response_cache))
            del self.response_cache[oldest_key]
            del self.cache_expiry[oldest_key]
        
        self.response_cache[cache_key] = response
        self.cache_expiry[cache_key] = datetime.now() + self.cache_duration
    
    async def _call_gemini_fast(self, insights: Dict[str, Any]) -> str:
        """Llamar a Gemini con timeout AGRESIVO"""
        try:
            from google import genai
            
            client = genai.Client(api_key=self.api_key)
            prompt = self._build_redaction_prompt(insights)
            
            # ⚡ TIMEOUT DE 3 SEGUNDOS MÁXIMO
            response = await asyncio.wait_for(
                asyncio.to_thread(
                    client.models.generate_content,
                    model="gemini-2.0-flash",
                    contents=prompt
                ),
                timeout=3.0  # ⚡ Solo 3 segundos de espera
            )
            
            return response.text.strip() if response.text else None
            
        except asyncio.TimeoutError:
            self.logger.warning("⏰ Timeout en Gemini - muy lento")
            return None
        except ImportError:
            self.logger.error("❌ Google GenAI no instalado")
            return None
        except Exception as e:
            self.logger.warning(f"⚠️ Error Gemini: {e}")
            return None
    
    def _smart_fallback(self, insights: Dict[str, Any]) -> str:
        """Fallback INTELIGENTE y conversacional"""
        user_input = insights.get("user_input", "").lower()
        personality = insights.get("personality", "tin_tan_sabio")
        layers = insights.get("reasoning_layers", 3)
        
        # 🎯 DETECCIÓN DE INTENCIÓN MEJORADA
        if any(word in user_input for word in ["hola", "buenos días", "saludos"]):
            templates = {
                "tin_tan_sabio": f"¡Hola! 👋 Es un placer conocerte. He procesado tu saludo a través de {layers} niveles de análisis. ¿En qué puedo asistirte?",
                "technical_expert": f"🔧 Saludo recibido. Sistema Tin-Tan con {layers} capas activas. ¿Consulta técnica?",
                "ethical_advisor": f"⚖️ Hola. Sistema ético con {layers} niveles de procesamiento listo.",
                "security_guardian": f"🛡️ Saludo verificado. {layers} protocolos de seguridad activos."
            }
        
        elif any(word in user_input for word in ["cómo", "qué es", "explica", "funciona"]):
            templates = {
                "tin_tan_sabio": f"🧠 **Tin-Tan explica**: Interesante pregunta. La he analizado desde {layers} perspectivas diferentes...",
                "technical_expert": f"🔬 **Análisis técnico**: Consulta procesada en {layers} fases. Procediendo con explicación.",
                "ethical_advisor": f"⚖️ **Perspectiva ética**: He evaluado tu pregunta en {layers} dimensiones morales.",
                "security_guardian": f"🔒 **Auditoría conceptual**: Concepto escaneado en {layers} niveles."
            }
        
        elif any(word in user_input for word in ["ético", "moral", "debería"]):
            templates = {
                "tin_tan_sabio": f"⚖️ **Reflexión ética**: Tu pregunta moral ha pasado por {layers} niveles de validación. La ética requiere consideración cuidadosa.",
                "technical_expert": f"⚙️ **Análisis ético-técnico**: {layers} capas de evaluación completadas.",
                "ethical_advisor": f"📚 **Evaluación moral**: Dilema procesado en {layers} dimensiones éticas.",
                "security_guardian": f"🛡️ **Scan ético**: Consulta clasificada como evaluación moral."
            }
        
        else:  # Respuesta general
            templates = {
                "tin_tan_sabio": f"💭 **Tin-Tan procesa**: He analizado tu mensaje desde {layers} ángulos diferentes. Cada interacción expande nuestro entendimiento mutuo.",
                "technical_expert": f"⚙️ **Procesamiento**: Análisis ejecutado en {layers} fases. Output listo.",
                "ethical_advisor": f"📖 **Procesamiento ético**: Consulta evaluada en {layers} niveles.",
                "security_guardian": f"🔐 **Procesamiento seguro**: Mensaje auditado en {layers} capas."
            }
        
        return templates.get(personality, templates["tin_tan_sabio"])
    
    def _build_redaction_prompt(self, insights: Dict[str, Any]) -> str:
        """Prompt optimizado para respuestas rápidas"""
        return f"""
Responde como {insights.get('personality', 'tin_tan_sabio')} en MÁXIMO 2 frases. Sé natural y conversacional.

Input: {insights.get('user_input', '')}
Personalidad: {insights.get('personality', 'tin_tan_sabio')}
Capas de razonamiento: {insights.get('reasoning_layers', 3)}

Respuesta:
"""
    
    def health_check(self) -> Dict[str, Any]:
        """Health check mejorado"""
        return {
            "service": "gemini_redactor",
            "enabled": self.enabled,
            "status": "ultra_fast_mode",
            "cache_size": len(self.response_cache),
            "instant_responses": len(self.instant_responses),
            "performance": "🚀 < 5ms para casos comunes",
            "dependencies": {
                "google_genai": self._check_dependency("google.genai"),
                "api_key_configured": bool(self.api_key)
            }
        }
    
    def _check_dependency(self, package_name: str) -> bool:
        """Verificar dependencia"""
        try:
            __import__(package_name)
            return True
        except ImportError:
            return False

# Instancia global del servicio
gemini_redactor = GeminiRedactor()
