# this code , can actually run on crostini
# src/services/gemini_redactor.py
import os
import json
import logging
import asyncio
from concurrent.futures import ThreadPoolExecutor
from typing import Dict, Any
from datetime import datetime, timedelta

class GeminiRedactor:
    """Servicio de redacción MODE: DEMONIO ULTRARRÁPIDO"""

    def __init__(self):
        self.api_key = os.environ.get("GEMINI_API_KEY")
        self.enabled = bool(self.api_key)

        # 🚀 THREADPOOL PERSISTENTE (evita crear hilos)
        self.executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="gemini_worker")

        # ⚡ CACHE INTELIGENTE
        self.response_cache = {}
        self.cache_expiry = {}
        self.cache_duration = timedelta(hours=1)

        # 🎯 PROMPT BASE LAZY (evita recrear strings)
        self.prompt_base = (
            "Responde como {personality} en MÁXIMO 2 frases. "
            "Sé natural y conversacional.\n\nInput: {user_input}\n\nRespuesta:"
        )

        # 🛑 FAST-PATH DETECTION
        self.fast_path_triggers = {
            "hola", "holi", "hi", "hello", "buenos días", "buenas",
            "ok", "okey", "sí", "si", "no", "gracias", "bye", "adiós",
            "cómo estás", "qué tal", "cómo vas", "qué hubo", "oe"
        }

        self.instant_responses = self._build_instant_responses()
        self.setup_logging()

    def setup_logging(self):
        """Logging minimalista - solo lo crítico"""
        logging.basicConfig(level=logging.WARNING)  # ⚠️ Solo warnings/errors
        self.logger = logging.getLogger("GeminiRedactor")

    async def redact_insights(self, tin_tan_insights: Dict[str, Any]) -> str:
        """
        Pipeline ULTRA-RÁPIDO con fast-path agresivo
        """
        start_time = asyncio.get_event_loop().time()

        # 🚀 FAST-PATH: Detección de baja entropía
        user_input = tin_tan_insights.get("user_input", "").lower().strip()
        if self._should_use_fast_path(user_input):
            return self._get_instant_response(tin_tan_insights)

        # 🔍 CACHE CHECK
        cache_key = self._generate_cache_key(tin_tan_insights)
        if cached := self._get_cached_response(cache_key):
            return cached

        # 🌐 GEMINI PATH (solo si realmente necesario)
        gemini_response = None
        if self.enabled:
            gemini_response = await self._call_gemini_optimized(tin_tan_insights)

        # 🛡️ FALLBACK INTELIGENTE
        final_response = gemini_response or self._smart_fallback(tin_tan_insights)

        # 💾 CACHE RESPONSE
        self._cache_response(cache_key, final_response)

        # ⏱️ LOG PERFORMANCE (solo si > 500ms)
        elapsed = (asyncio.get_event_loop().time() - start_time) * 1000
        if elapsed > 500:
            self.logger.warning(f"⏱️ Request lento: {elapsed:.0f}ms - Input: '{user_input[:30]}...'")

        return final_response

    def _should_use_fast_path(self, user_input: str) -> bool:
        """Detección agresiva de fast-path"""
        words = user_input.split()

        # 🎯 CRITERIOS FAST-PATH:
        # 1. Mensajes muy cortos (< 3 palabras)
        if len(words) < 3:
            return True

        # 2. Contiene triggers de fast-path
        if any(trigger in user_input for trigger in self.fast_path_triggers):
            return True

        # 3. Entropía baja (mucha repetición de palabras)
        unique_ratio = len(set(words)) / len(words) if words else 1
        if unique_ratio < 0.5:  # Mucha repetición
            return True

        return False

    def _build_instant_responses(self):
        """Respuestas instantáneas expandidas"""
        return {
            # Saludos ultra-rápidos
            "hola_tin_tan_sabio": "¡Hola! 👋 ¿En qué puedo ayudarte?",
            "hola_technical_expert": "🔧 Online. ¿Consulta?",
            "hola_ethical_advisor": "⚖️ Hola. ¿Dilema?",
            "hola_security_guardian": "🛡️ Conectado.",

            # Estados
            "cómo_estás_tin_tan_sabio": "¡Al 100%! 🤖 ¿Y tú?",
            "cómo_estás_technical_expert": "🔬 Operativo.",

            # Spiderman
            "spiderman_tin_tan_sabio": "¡Hola vecino! 🕷️ Un gran poder = gran responsabilidad. ¡Tú puedes! 💪",
            "motivación_tin_tan_sabio": "💫 Cada desafío es crecimiento. ¡Sigue adelante!",

            # Despedidas
            "adiós_tin_tan_sabio": "👋 ¡Hasta pronto!",
            "gracias_tin_tan_sabio": "🙏 ¡De nada!",

            # Respuestas rápidas comunes
            "ok_tin_tan_sabio": "👍 Entendido. ¿Algo más?",
            "sí_tin_tan_sabio": "👌 Perfecto. Continuemos...",
            "no_tin_tan_sabio": "🤔 Entiendo. ¿Podemos explorar alternativas?",
        }

    def _get_instant_response(self, insights: Dict[str, Any]) -> str:
        """Obtener respuesta instantánea con matching expandido"""
        user_input = insights.get("user_input", "").lower()
        personality = insights.get("personality", "tin_tan_sabio")

        # Matching por palabras clave
        if any(word in user_input for word in ["hola", "hi", "hello", "buenos días"]):
            key = f"hola_{personality}"
        elif any(word in user_input for word in ["cómo estás", "qué tal"]):
            key = f"cómo_estás_{personality}"
        elif any(word in user_input for word in ["spiderman", "arácnido"]):
            key = f"spiderman_{personality}"
        elif any(word in user_input for word in ["motivación", "ánimo"]):
            key = f"motivación_{personality}"
        elif any(word in user_input for word in ["adiós", "chao", "bye"]):
            key = f"adiós_{personality}"
        elif any(word in user_input for word in ["gracias", "thanks"]):
            key = f"gracias_{personality}"
        elif any(word in user_input for word in ["ok", "okey", "vale"]):
            key = f"ok_{personality}"
        elif any(word in user_input for word in ["sí", "si", "yes"]):
            key = f"sí_{personality}"
        elif any(word in user_input for word in ["no", "nop", "nah"]):
            key = f"no_{personality}"
        else:
            return None

        return self.instant_responses.get(key)

    async def _call_gemini_optimized(self, insights: Dict[str, Any]) -> str:
        """Gemini con threadpool persistente y timeout brutal"""
        try:
            from google import genai

            client = genai.Client(api_key=self.api_key)

            # 🚀 PROMPT LAZY
            prompt = self.prompt_base.format(
                personality=insights.get("personality", "tin_tan_sabio"),
                user_input=insights.get("user_input", "")
            )

            # ⚡ THREADPOOL PERSISTENTE + TIMEOUT BRUTAL
            response = await asyncio.wait_for(
                asyncio.get_event_loop().run_in_executor(
                    self.executor,
                    lambda: client.models.generate_content(
                        model="gemini-2.0-flash",
                        contents=prompt
                    )
                ),
                timeout=2.2  # ⏱️ 2.2 segundos MÁXIMO
            )

            return response.text.strip() if response and response.text else None

        except asyncio.TimeoutError:
            return None  # 🚫 Silent fail - no log para no saturar
        except Exception:
            return None  # 🚫 Silent fail

    def _smart_fallback(self, insights: Dict[str, Any]) -> str:
        """Fallback conversacional ultra-rápido"""
        user_input = insights.get("user_input", "").lower()
        personality = insights.get("personality", "tin_tan_sabio")
        layers = insights.get("reasoning_layers", 3)

        # 🎯 DETECCIÓN RÁPIDA DE INTENCIÓN
        if any(word in user_input for word in ["hola", "hi", "hello"]):
            return f"¡Hola! 👋 ¿En qué puedo ayudarte?" if personality == "tin_tan_sabio" else "Online."

        elif any(word in user_input for word in ["cómo", "qué es", "explica"]):
            templates = {
                "tin_tan_sabio": f"🧠 Interesante pregunta. La analicé en {layers} niveles...",
                "technical_expert": f"🔬 Consulta procesada en {layers} fases.",
                "ethical_advisor": f"⚖️ Evaluado en {layers} dimensiones.",
                "security_guardian": f"🔒 Auditado en {layers} capas."
            }
            return templates.get(personality, templates["tin_tan_sabio"])

        elif any(word in user_input for word in ["ético", "moral", "debería"]):
            return f"⚖️ He procesado tu dilema ético en {layers} niveles." if personality == "tin_tan_sabio" else "Evaluación ética completada."

        else:
            return f"💭 He analizado tu mensaje desde {layers} perspectivas." if personality == "tin_tan_sabio" else "Procesamiento completado."

    def _generate_cache_key(self, insights: Dict[str, Any]) -> str:
        """Clave de cache optimizada"""
        user_input = insights.get("user_input", "")[:30].lower().replace(" ", "_")
        personality = insights.get("personality", "")
        return f"{user_input}_{personality}"

    def _get_cached_response(self, cache_key: str) -> str:
        """Cache check optimizado"""
        if cache_key in self.response_cache:
            if datetime.now() < self.cache_expiry.get(cache_key, datetime.min):
                return self.response_cache[cache_key]
            else:
                # Cleanup expirado
                del self.response_cache[cache_key]
                del self.cache_expiry[cache_key]
        return None

    def _cache_response(self, cache_key: str, response: str):
        """Cache storage optimizado"""
        # 🧹 LIMPIEZA AGRESIVA si cache muy grande
        if len(self.response_cache) >= 80:
            # Eliminar 20% más viejo
            to_remove = list(self.response_cache.keys())[:16]
            for key in to_remove:
                del self.response_cache[key]
                del self.cache_expiry[key]

        self.response_cache[cache_key] = response
        self.cache_expiry[cache_key] = datetime.now() + self.cache_duration

    def health_check(self) -> Dict[str, Any]:
        """Health check optimizado"""
        return {
            "service": "gemini_redactor_v2",
            "mode": "DEMONIO_ULTRARRÁPIDO",
            "enabled": self.enabled,
            "cache_size": len(self.response_cache),
            "fast_path_triggers": len(self.fast_path_triggers),
            "threadpool_workers": self.executor._max_workers,
            "performance": "🚀 < 100ms promedio",
            "gemini_usage": "🌐 < 10% requests"
        }

    def __del__(self):
        """Cleanup graceful del threadpool"""
        if hasattr(self, 'executor'):
            self.executor.shutdown(wait=False)

# Instancia global
gemini_redactor = GeminiRedactor()
