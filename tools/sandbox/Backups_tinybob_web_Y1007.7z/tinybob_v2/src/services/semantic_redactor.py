# lightweight_semantic.py
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import json
from typing import Dict, List
import re

class LightweightSemantic:
    def __init__(self):
        self.enabled = True
        self.vectorizer = None
        self.concept_vectors = None
        self.concepts = []
        
        try:
            self._initialize_semantic_system()
            print("✅ Sistema semántico liviano inicializado")
        except Exception as e:
            print(f"❌ Error en sistema semántico: {e}")
            self.enabled = False
    
    def _initialize_semantic_system(self):
        """Inicializa sistema semántico usando TF-IDF (sin dependencias pesadas)"""
        
        # Conceptos del dominio AGI - en español para mejor matching
        self.concepts = [
            # Núcleo AGI
            "inteligencia artificial", "algoritmo machine learning", "red neuronal profunda",
            "procesamiento lenguaje natural", "razonamiento automático", "sistema autónomo",
            
            # Dominios Tin-Tan
            "orquestación inteligente", "ética artificial", "seguridad cibernética", 
            "análisis contextual", "respuesta coherente", "arquitectura multinivel",
            
            # Personalidades
            "tin tan sabio", "experto técnico", "consejero ético", "guardián seguridad",
            
            # Conceptos conversación
            "diálogo inteligente", "comprensión semántica", "adaptación conversacional"
        ]
        
        # Inicializar vectorizer TF-IDF
        self.vectorizer = TfidfVectorizer(
            lowercase=True,
            stop_words=['de', 'la', 'que', 'el', 'en', 'y', 'a', 'los', 'del', 'se', 'las', 'por', 'un', 'para', 'con', 'no', 'una', 'su', 'al', 'lo', 'como', 'más', 'pero', 'sus', 'le', 'ya', 'o', 'este', 'sí', 'porque', 'esta', 'entre', 'cuando', 'muy', 'sin', 'sobre', 'también', 'me', 'hasta', 'hay', 'donde', 'quien', 'desde', 'todo', 'nos', 'durante', 'todos', 'uno', 'les', 'ni', 'contra', 'otros', 'ese', 'eso', 'ante', 'ellos', 'e', 'esto', 'mí', 'antes', 'algunos', 'qué', 'unos', 'yo', 'otro', 'otras', 'otra', 'él', 'tanto', 'esa', 'estos', 'mucho', 'quienes', 'nada', 'muchos', 'cual', 'poco', 'ella', 'estar', 'estas', 'algunas', 'algo', 'nosotros', 'mi', 'mis', 'tú', 'te', 'ti', 'tu', 'tus', 'ellas', 'nosotras', 'vosostros', 'vosostras', 'os', 'mío', 'mía', 'míos', 'mías', 'tuyo', 'tuya', 'tuyos', 'tuyas', 'suyo', 'suya', 'suyos', 'suyas', 'nuestro', 'nuestra', 'nuestros', 'nuestras', 'vuestro', 'vuestra', 'vuestros', 'vuestras', 'esos', 'esas', 'estoy', 'estás', 'está', 'estamos', 'estáis', 'están', 'esté', 'estés', 'estemos', 'estéis', 'estén', 'estaré', 'estarás', 'estará', 'estaremos', 'estaréis', 'estarán', 'estaría', 'estarías', 'estaríamos', 'estaríais', 'estarían', 'estaba', 'estabas', 'estábamos', 'estabais', 'estaban', 'estuve', 'estuviste', 'estuvo', 'estuvimos', 'estuvisteis', 'estuvieron', 'estuviera', 'estuvieras', 'estuviéramos', 'estuvierais', 'estuvieran', 'estuviese', 'estuvieses', 'estuviésemos', 'estuvieseis', 'estuviesen', 'estando', 'estado', 'estada', 'estados', 'estadas', 'estad', 'he', 'has', 'ha', 'hemos', 'habéis', 'han', 'haya', 'hayas', 'hayamos', 'hayáis', 'hayan', 'habré', 'habrás', 'habrá', 'habremos', 'habréis', 'habrán', 'habría', 'habrías', 'habríamos', 'habríais', 'habrían', 'había', 'habías', 'habíamos', 'habíais', 'habían', 'hube', 'hubiste', 'hubo', 'hubimos', 'hubisteis', 'hubieron', 'hubiera', 'hubieras', 'hubiéramos', 'hubierais', 'hubieran', 'hubiese', 'hubieses', 'hubiésemos', 'hubieseis', 'hubiesen', 'habiendo', 'habido', 'habida', 'habidos', 'habidas', 'soy', 'eres', 'es', 'somos', 'sois', 'son', 'sea', 'seas', 'seamos', 'seáis', 'sean', 'seré', 'serás', 'será', 'seremos', 'seréis', 'serán', 'sería', 'serías', 'seríamos', 'seríais', 'serían', 'era', 'eras', 'éramos', 'erais', 'eran', 'fui', 'fuiste', 'fue', 'fuimos', 'fuisteis', 'fueron', 'fuera', 'fueras', 'fuéramos', 'fuerais', 'fueran', 'fuese', 'fueses', 'fuésemos', 'fueseis', 'fuesen', 'sintiendo', 'sentido', 'sentida', 'sentidos', 'sentidas', 'siente', 'sentid', 'tengo', 'tienes', 'tiene', 'tenemos', 'tenéis', 'tienen', 'tenga', 'tengas', 'tengamos', 'tengáis', 'tengan', 'tendré', 'tendrás', 'tendrá', 'tendremos', 'tendréis', 'tendrán', 'tendría', 'tendrías', 'tendríamos', 'tendríais', 'tendrían', 'tenía', 'tenías', 'teníamos', 'teníais', 'tenían', 'tuve', 'tuviste', 'tuvo', 'tuvimos', 'tuvisteis', 'tuvieron', 'tuviera', 'tuvieras', 'tuviéramos', 'tuvierais', 'tuvieran', 'tuviese', 'tuvieses', 'tuviésemos', 'tuvieseis', 'tuviesen', 'teniendo', 'tenido', 'tenida', 'tenidos', 'tenidas', 'tened'],
            max_features=100
        )
        
        # Entrenar el vectorizer con los conceptos
        self.concept_vectors = self.vectorizer.fit_transform(self.concepts)
    
    def semantic_analysis(self, text: str) -> Dict:
        """Análisis semántico usando TF-IDF"""
        if not self.enabled:
            return {"error": "Sistema semántico no disponible"}
        
        try:
            # Vectorizar el texto de entrada
            text_vector = self.vectorizer.transform([text])
            
            # Calcular similitudes con todos los conceptos
            similarities = cosine_similarity(text_vector, self.concept_vectors)[0]
            
            # Encontrar conceptos más relevantes
            concept_similarities = []
            for i, similarity in enumerate(similarities):
                if similarity > 0.1:  # Umbral bajo para TF-IDF
                    concept_similarities.append({
                        "concept": self.concepts[i],
                        "similarity": float(similarity),
                        "category": self._categorize_concept(self.concepts[i])
                    })
            
            # Ordenar por relevancia
            concept_similarities.sort(key=lambda x: x["similarity"], reverse=True)
            top_concepts = concept_similarities[:3]
            
            return {
                "input": text,
                "top_concepts": top_concepts,
                "semantic_density": len(top_concepts),
                "primary_concept": top_concepts[0]["concept"] if top_concepts else "general",
                "confidence": top_concepts[0]["similarity"] if top_concepts else 0.0,
                "method": "tfidf_cosine"
            }
            
        except Exception as e:
            return {"error": f"Error en análisis semántico: {str(e)}"}
    
    def enhance_response(self, user_input: str, original_response: str, personality: str) -> str:
        """Mejora la respuesta con análisis semántico liviano"""
        if not self.enabled:
            return original_response
        
        try:
            analysis = self.semantic_analysis(user_input)
            
            if "error" in analysis or not analysis.get("top_concepts"):
                return original_response
            
            top_concepts = analysis["top_concepts"]
            primary_concept = analysis["primary_concept"]
            confidence = analysis["confidence"]
            
            # Mejora basada en personalidad
            enhancements = {
                "tin_tan_sabio": f"\n\n🔍 **Dimensión semántica**: Desde '{primary_concept}' (confianza: {confidence:.2f}), se revelan capas adicionales de significado.",
                "technical_expert": f"\n\n🔧 **Contexto técnico**: Enmarcado en '{primary_concept}', el análisis semántico refuerza la precisión técnica.",
                "ethical_advisor": f"\n\n⚖️ **Perspectiva ética**: Considerando '{primary_concept}', se integran dimensiones morales relevantes.",
                "security_guardian": f"\n\n🛡️ **Marco de seguridad**: Desde '{primary_concept}', se aplican consideraciones protectoras adicionales."
            }
            
            enhancement = enhancements.get(personality, enhancements["tin_tan_sabio"])
            
            # Solo añadir mejora si hay suficiente confianza
            if confidence > 0.2:
                return original_response + enhancement
            else:
                return original_response
                
        except Exception as e:
            print(f"⚠️ Error en mejora semántica: {e}")
            return original_response
    
    def _categorize_concept(self, concept: str) -> str:
        """Categorización simple de conceptos"""
        concept_lower = concept.lower()
        
        if any(word in concept_lower for word in ['ético', 'moral', 'consejero']):
            return "ético"
        elif any(word in concept_lower for word in ['seguridad', 'guardián', 'protección']):
            return "seguridad"
        elif any(word in concept_lower for word in ['técnico', 'algoritmo', 'machine', 'red neuronal']):
            return "técnico"
        elif any(word in concept_lower for word in ['sabio', 'razonamiento', 'inteligencia']):
            return "sabio"
        else:
            return "general"

# Instancia global
semantic_service = LightweightSemantic()

# Funciones de compatibilidad
async def redact_insights(insights: Dict) -> str:
    """Interfaz compatible para el sistema existente"""
    user_input = insights.get("user_input", "")
    original_response = insights.get("response", "")
    personality = insights.get("personality", "tin_tan_sabio")
    
    return semantic_service.enhance_response(user_input, original_response, personality)

def health_check():
    return {
        "service": "lightweight_semantic",
        "status": "operational" if semantic_service.enabled else "degraded",
        "concepts_loaded": len(semantic_service.concepts),
        "method": "tfidf_cosine_similarity",
        "dependencies": "scikit-learn only"
    }