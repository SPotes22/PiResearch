# src/services/gemini_redactor.py
import os
import json
import logging
from typing import Dict, Any

class GeminiRedactor:
    """Servicio de redacción que convierte insights estructurados en texto natural"""
    
    def __init__(self):
        self.api_key = os.environ.get("GEMINI_API_KEY")
        self.enabled = bool(self.api_key)
        self.setup_logging()
    
    def setup_logging(self):
        """Configurar logging del servicio"""
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger("GeminiRedactor")
    
    async def redact_insights(self, tin_tan_insights: Dict[str, Any]) -> str:
        """
        Convertir insights estructurados de Tin-Tan en texto natural
        
        Args:
            tin_tan_insights: Output estructurado del núcleo AGI
            
        Returns:
            str: Texto natural redactado
        """
        if not self.enabled:
            self.logger.warning("Gemini API key no configurada - usando fallback")
            return self._fallback_redaction(tin_tan_insights)
        
        try:
            return await self._call_gemini_api(tin_tan_insights)
        except Exception as e:
            self.logger.error(f"Error en redacción Gemini: {e}")
            return self._fallback_redaction(tin_tan_insights)
    
    async def _call_gemini_api(self, insights: Dict[str, Any]) -> str:
        """Llamar a la API de Gemini para redacción"""
        try:
            # Import condicional para evitar dependencias innecesarias
            from google import genai
            from google.genai import types
            
            client = genai.Client(api_key=self.api_key)
            
            # Preparar prompt estructurado
            prompt = self._build_redaction_prompt(insights)
            
            response = client.models.generate_content(
                model="gemini-2.0-flash",
                contents=prompt
            )
            
            return response.text.strip()
            
        except ImportError:
            self.logger.error("Google GenAI no instalado - pip install google-genai")
            return self._fallback_redaction(insights)
        except Exception as e:
            self.logger.error(f"Error API Gemini: {e}")
            return self._fallback_redaction(insights)
    
    def _build_redaction_prompt(self, insights: Dict[str, Any]) -> str:
        """Construir prompt para Gemini basado en insights"""
        
        base_prompt = """
Eres un **traductor emocional** para un AGI llamado Tin-Tan. Tu trabajo es convertir insights técnicos en respuestas naturales y empáticas.

## REGLAS ESTRICTAS:
1. MANTENER el tono de personalidad especificado
2. PRESERVAR todos los insights de seguridad/ética
3. HACER sonar humano sin perder precisión técnica
4. USAR emojis relevantes pero no excesivos
5. MÁXIMO 3 frases - ser conciso pero cálido

## INPUT ESTRUCTURADO:
{insights_json}

## PERSONALIDAD ASIGNADA: {personality}

Traduce esto a una respuesta natural que suene como {personality}:
"""
        
        return base_prompt.format(
            insights_json=json.dumps(insights, ensure_ascii=False, indent=2),
            personality=insights.get("personality", "tin_tan_sabio")
        )
    
    def _fallback_redaction(self, insights: Dict[str, Any]) -> str:
        """Redacción de fallback cuando Gemini no está disponible"""
        
        personality = insights.get("personality", "tin_tan_sabio")
        intent = insights.get("detected_intent", "general")
        emotion = insights.get("emotional_tone", "neutral")
        
        # Templates de fallback por personalidad e intención
        fallback_templates = {
            "tin_tan_sabio": {
                "greeting": "👋 ¡Hola! Tin-Tan aquí, con mis {layers} capas de razonamiento activas. ¿En qué puedo asistirte hoy?",
                "ethical_inquiry": "⚖️ **Reflexión Tin-Tan**: Tu pregunta ética ha pasado por {layers} niveles de análisis. El equilibrio moral requiere consideración cuidadosa.",
                "security_concern": "🛡️ **Alerta Tin-Tan**: He procesado tu consulta de seguridad en {layers} fases. La protección proactiva es esencial.",
                "general": "🧠 **Tin-Tan analiza**: Tu consulta activó {layers} niveles de procesamiento. Cada pregunta expande nuestro understanding mutuo."
            },
            "technical_expert": {
                "greeting": "🔧 Sistema Tin-Tan Técnico online. {layers} capas operativas. ¿Consulta?",
                "ethical_inquiry": "⚙️ **Análisis ético-técnico**: {layers} capas de evaluación completadas. Variables morales procesadas.",
                "security_concern": "🔒 **Scan técnico**: {layers} protocolos de seguridad ejecutados. Estado: protegido.",
                "general": "🔬 **Procesamiento técnico**: {layers} niveles de análisis ejecutados. Output listo."
            }
        }
        
        template_group = fallback_templates.get(personality, fallback_templates["tin_tan_sabio"])
        template = template_group.get(intent, template_group["general"])
        
        return template.format(layers=insights.get("reasoning_layers", 3))
    
    def health_check(self) -> Dict[str, Any]:
        """Verificar estado del servicio"""
        return {
            "service": "gemini_redactor",
            "enabled": self.enabled,
            "status": "operational" if self.enabled else "fallback_mode",
            "dependencies": {
                "google_genai": self._check_dependency("google.genai"),
                "api_key_configured": bool(self.api_key)
            }
        }
    
    def _check_dependency(self, package_name: str) -> bool:
        """Verificar si una dependencia está disponible"""
        try:
            __import__(package_name)
            return True
        except ImportError:
            return False

# Instancia global del servicio
gemini_redactor = GeminiRedactor()
