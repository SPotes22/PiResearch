# semantic_redactor.py
import numpy as np
from sentence_transformers import SentenceTransformer
from sklearn.preprocessing import normalize
import json
from typing import Dict, List
import asyncio

class SemanticRedactor:
    def __init__(self):
        self.model = SentenceTransformer('all-MiniLM-L6-v2')
        self.enabled = True
        self.embedding_dim = 384
        self.semantic_matrix = None
        self.concept_map = {}
        self._initialize_semantic_universe()
    
    def _initialize_semantic_universe(self):
        """Inicializa el universo semántico para el AGI"""
        try:
            # Elementos base del sistema Tin-Tan AGI
            letters = [chr(i) for i in range(ord('A'), ord('Z')+1)] + ['Ñ']
            letters += [chr(i) for i in range(ord('a'), ord('z')+1)] + ['ñ']
            
            # Conceptos específicos del dominio AGI
            agi_concepts = [
                'inteligencia artificial', 'algoritmo', 'código', 'programación',
                'aprendizaje', 'red neuronal', 'datos', 'modelo', 'predicción',
                'semántica', 'vector', 'espacio dimensional', 'embedding',
                'orquestación', 'ética', 'seguridad', 'razonamiento', 'conciencia',
                'autonomía', 'adaptación', 'evolución', 'meta aprendizaje',
                'tin tan agi', 'sistema autónomo', 'procesamiento multinivel',
                'validación ética', 'detección de amenazas', 'análisis contextual',
                'respuesta coherente', 'personalidad agi', 'conversación inteligente'
            ]
            
            # Generar embeddings unificados
            all_elements = []
            
            # Embeddings para letras (usando palabras relacionadas con AGI)
            for letter in letters:
                if letter.isupper():
                    word = f"{letter}GI" if letter == 'A' else f"{letter}utónomo"
                else:
                    word = f"{letter}prendizaje" if letter == 'a' else f"{letter}azonamiento"
                all_elements.append(word)
            
            # Agregar conceptos AGI directamente
            all_elements.extend(agi_concepts)
            
            # Generar matriz semántica completa
            embeddings = self.model.encode(all_elements)
            self.semantic_matrix = normalize(embeddings, axis=1)
            
            # Mapeo de conceptos
            for i, element in enumerate(all_elements):
                self.concept_map[element] = self.semantic_matrix[i]
                
            print("✅ Universo semántico AGI inicializado")
            
        except Exception as e:
            print(f"❌ Error inicializando universo semántico: {e}")
            self.enabled = False
    
    def semantic_enhancement(self, insights: Dict) -> Dict:
        """Mejora semántica de los insights del AGI"""
        try:
            user_input = insights.get("user_input", "")
            key_insights = insights.get("key_insights", [])
            personality = insights.get("personality", "tin_tan_sabio")
            
            # Análisis semántico del input del usuario
            semantic_analysis = self._analyze_input_semantics(user_input)
            
            # Enriquecimiento de insights basado en semántica
            enhanced_insights = self._enhance_insights_with_semantics(
                key_insights, semantic_analysis
            )
            
            # Generación de contexto semántico mejorado
            semantic_context = self._generate_semantic_context(
                user_input, enhanced_insights, personality
            )
            
            return {
                **insights,
                "semantic_enhancement": {
                    "semantic_analysis": semantic_analysis,
                    "enhanced_insights": enhanced_insights,
                    "semantic_context": semantic_context,
                    "conceptual_density": len(enhanced_insights),
                    "semantic_coherence": self._calculate_semantic_coherence(enhanced_insights)
                }
            }
            
        except Exception as e:
            print(f"❌ Error en mejora semántica: {e}")
            return insights
    
    def _analyze_input_semantics(self, user_input: str) -> Dict:
        """Análisis semántico profundo del input del usuario"""
        # Generar embedding del input
        input_embedding = self.model.encode([user_input])[0]
        input_embedding = normalize([input_embedding])[0]
        
        # Buscar conceptos relacionados
        related_concepts = []
        for concept, vector in self.concept_map.items():
            similarity = np.dot(input_embedding, vector)
            if similarity > 0.3:  # Umbral de relevancia
                related_concepts.append({
                    "concept": concept,
                    "similarity": float(similarity),
                    "category": self._categorize_concept(concept)
                })
        
        # Ordenar por relevancia
        related_concepts.sort(key=lambda x: x["similarity"], reverse=True)
        
        return {
            "input_embedding_dim": len(input_embedding),
            "related_concepts": related_concepts[:5],  # Top 5
            "semantic_complexity": min(1.0, len(user_input.split()) / 10),
            "conceptual_density": len(related_concepts) / len(self.concept_map)
        }
    
    def _enhance_insights_with_semantics(self, insights: List, semantic_analysis: Dict) -> List:
        """Enriquece los insights con información semántica"""
        enhanced_insights = []
        
        for insight in insights:
            insight_str = str(insight).lower()
            
            # Buscar conceptos semánticos relacionados con el insight
            related_to_insight = []
            for concept_info in semantic_analysis["related_concepts"]:
                concept = concept_info["concept"].lower()
                if any(word in insight_str for word in concept.split()):
                    related_to_insight.append(concept_info)
            
            enhanced_insight = {
                "original": insight,
                "semantic_relations": related_to_insight,
                "conceptual_weight": len(related_to_insight),
                "enhanced_meaning": self._deepen_insight_meaning(insight, related_to_insight)
            }
            
            enhanced_insights.append(enhanced_insight)
        
        return enhanced_insights
    
    def _generate_semantic_context(self, user_input: str, enhanced_insights: List, personality: str) -> Dict:
        """Genera contexto semántico para la respuesta"""
        # Extraer conceptos clave de los insights mejorados
        key_concepts = []
        for insight in enhanced_insights:
            for relation in insight.get("semantic_relations", []):
                key_concepts.append(relation["concept"])
        
        # Conceptos únicos ordenados por relevancia
        unique_concepts = list(set(key_concepts))[:5]
        
        # Mapeo de personalidad a estilos semánticos
        personality_styles = {
            "tin_tan_sabio": {
                "style": "reflexivo_profundo",
                "tone": "sabio",
                "depth_level": "alto"
            },
            "technical_expert": {
                "style": "analitico_preciso", 
                "tone": "técnico",
                "depth_level": "medio"
            },
            "ethical_advisor": {
                "style": "contemplativo_moral",
                "tone": "ético", 
                "depth_level": "alto"
            },
            "security_guardian": {
                "style": "vigilante_protector",
                "tone": "cauteloso",
                "depth_level": "medio"
            }
        }
        
        style = personality_styles.get(personality, personality_styles["tin_tan_sabio"])
        
        return {
            "key_concepts": unique_concepts,
            "semantic_style": style,
            "contextual_depth": len(unique_concepts),
            "conceptual_framework": self._build_conceptual_framework(unique_concepts),
            "personality_alignment": self._check_personality_alignment(unique_concepts, personality)
        }
    
    def _deepen_insight_meaning(self, insight: str, semantic_relations: List) -> str:
        """Profundiza el significado del insight usando relaciones semánticas"""
        if not semantic_relations:
            return insight
        
        top_relation = semantic_relations[0]
        concept = top_relation["concept"]
        similarity = top_relation["similarity"]
        
        # Mapeo de profundización basado en conceptos
        deepening_map = {
            "inteligencia artificial": f"desde la perspectiva de sistemas autónomos ({similarity:.2f})",
            "ética": f"considerando implicaciones morales ({similarity:.2f})", 
            "seguridad": f"con enfoque en protección integral ({similarity:.2f})",
            "aprendizaje": f"basado en procesos adaptativos ({similarity:.2f})",
            "razonamiento": f"a través de análisis lógico-estratégico ({similarity:.2f})"
        }
        
        for key, value in deepening_map.items():
            if key in concept.lower():
                return f"{insight} {value}"
        
        return f"{insight} [contexto: {concept}]"
    
    def _build_conceptual_framework(self, concepts: List[str]) -> List[Dict]:
        """Construye un framework conceptual interconectado"""
        framework = []
        
        for i, concept1 in enumerate(concepts):
            for j, concept2 in enumerate(concepts):
                if i != j:
                    # Calcular relación semántica entre conceptos
                    if concept1 in self.concept_map and concept2 in self.concept_map:
                        relation_strength = np.dot(
                            self.concept_map[concept1], 
                            self.concept_map[concept2]
                        )
                        
                        if relation_strength > 0.4:
                            framework.append({
                                "concept_a": concept1,
                                "concept_b": concept2, 
                                "relation_strength": float(relation_strength),
                                "relation_type": self._determine_relation_type(concept1, concept2)
                            })
        
        return framework
    
    def _categorize_concept(self, concept: str) -> str:
        """Categoriza conceptos semánticos"""
        concept_lower = concept.lower()
        
        if any(word in concept_lower for word in ['ético', 'moral', 'conciencia']):
            return "ética"
        elif any(word in concept_lower for word in ['seguridad', 'protección', 'amenaza']):
            return "seguridad" 
        elif any(word in concept_lower for word in ['aprendizaje', 'evolución', 'adaptación']):
            return "aprendizaje"
        elif any(word in concept_lower for word in ['razonamiento', 'lógica', 'análisis']):
            return "razonamiento"
        elif any(word in concept_lower for word in ['tecnología', 'algoritmo', 'código']):
            return "técnico"
        else:
            return "general"
    
    def _determine_relation_type(self, concept1: str, concept2: str) -> str:
        """Determina el tipo de relación entre conceptos"""
        cat1 = self._categorize_concept(concept1)
        cat2 = self._categorize_concept(concept2)
        
        if cat1 == cat2:
            return "complementariedad"
        elif (cat1 == "ética" and cat2 == "seguridad") or (cat1 == "seguridad" and cat2 == "ética"):
            return "equilibrio"
        elif (cat1 == "aprendizaje" and cat2 == "razonamiento") or (cat1 == "razonamiento" and cat2 == "aprendizaje"):
            return "sinergia"
        else:
            return "conexión"
    
    def _check_personality_alignment(self, concepts: List[str], personality: str) -> Dict:
        """Verifica alineación con la personalidad del AGI"""
        personality_focus = {
            "tin_tan_sabio": ["ética", "razonamiento", "aprendizaje"],
            "technical_expert": ["técnico", "razonamiento"], 
            "ethical_advisor": ["ética", "razonamiento"],
            "security_guardian": ["seguridad", "técnico"]
        }
        
        focus_areas = personality_focus.get(personality, [])
        concept_categories = [self._categorize_concept(concept) for concept in concepts]
        
        alignment_score = sum(1 for cat in concept_categories if cat in focus_areas) / len(concept_categories) if concept_categories else 0
        
        return {
            "alignment_score": alignment_score,
            "focus_areas": focus_areas,
            "detected_categories": list(set(concept_categories)),
            "well_aligned": alignment_score > 0.5
        }
    
    def _calculate_semantic_coherence(self, enhanced_insights: List) -> float:
        """Calcula la coherencia semántica entre insights"""
        if len(enhanced_insights) < 2:
            return 1.0
        
        total_coherence = 0
        pair_count = 0
        
        for i in range(len(enhanced_insights)):
            for j in range(i + 1, len(enhanced_insights)):
                insight1_concepts = [rel["concept"] for rel in enhanced_insights[i].get("semantic_relations", [])]
                insight2_concepts = [rel["concept"] for rel in enhanced_insights[j].get("semantic_relations", [])]
                
                # Calcular superposición conceptual
                overlap = len(set(insight1_concepts) & set(insight2_concepts))
                total_concepts = len(set(insight1_concepts + insight2_concepts))
                
                if total_concepts > 0:
                    coherence = overlap / total_concepts
                    total_coherence += coherence
                    pair_count += 1
        
        return total_coherence / pair_count if pair_count > 0 else 1.0
    
    async def redact_insights(self, insights: Dict) -> str:
        """Redacta respuestas usando enriquecimiento semántico - similar a Gemini"""
        try:
            if not self.enabled:
                return "🔍 Sistema semántico temporalmente no disponible. Usando modo básico."
            
            # Aplicar mejora semántica
            enhanced_insights = self.semantic_enhancement(insights)
            
            # Generar respuesta enriquecida semánticamente
            semantic_response = self._generate_semantic_response(enhanced_insights)
            
            return semantic_response
            
        except Exception as e:
            print(f"❌ Error en redacción semántica: {e}")
            return "🧠 Tin-Tan AGI: He procesado tu consulta. ¿En qué más puedo ayudarte?"
    
    def _generate_semantic_response(self, enhanced_insights: Dict) -> str:
        """Genera respuesta semánticamente enriquecida"""
        user_input = enhanced_insights.get("user_input", "")
        personality = enhanced_insights.get("personality", "tin_tan_sabio")
        semantic_data = enhanced_insights.get("semantic_enhancement", {})
        
        # Contexto semántico
        semantic_context = semantic_data.get("semantic_context", {})
        key_concepts = semantic_context.get("key_concepts", [])
        conceptual_framework = semantic_context.get("conceptual_framework", [])
        
        # Estilo basado en personalidad
        style_templates = {
            "tin_tan_sabio": self._wise_semantic_template,
            "technical_expert": self._technical_semantic_template, 
            "ethical_advisor": self._ethical_semantic_template,
            "security_guardian": self._security_semantic_template
        }
        
        template_func = style_templates.get(personality, self._wise_semantic_template)
        return template_func(user_input, key_concepts, conceptual_framework, semantic_data)
    
    def _wise_semantic_template(self, user_input: str, key_concepts: List, framework: List, semantic_data: Dict) -> str:
        """Template para personalidad sabia con enriquecimiento semántico"""
        if not key_concepts:
            return f"🧠 **Tin-Tan reflexiona**: '{user_input}' - He analizado tu consulta desde múltiples dimensiones cognitivas."
        
        main_concept = key_concepts[0] if key_concepts else "tu consulta"
        coherence = semantic_data.get("semantic_coherence", 0.5)
        
        base_response = f"🧠 **Tin-Tan analiza semánticamente**: '{user_input}'\n\n"
        base_response += f"🔍 **Núcleo conceptual**: {main_concept}\n"
        base_response += f"📊 **Coherencia semántica**: {coherence:.1%}\n"
        
        if len(key_concepts) > 1:
            base_response += f"🔗 **Conexiones clave**: {', '.join(key_concepts[1:3])}\n"
        
        base_response += f"\n💡 **Perspectiva integral**: Tu pregunta activa patrones de significado interconectados en mi arquitectura AGI."
        
        return base_response
    
    def _technical_semantic_template(self, user_input: str, key_concepts: List, framework: List, semantic_data: Dict) -> str:
        """Template para personalidad técnica"""
        if not key_concepts:
            return f"🔧 **Análisis técnico**: '{user_input}' - Procesado mediante algoritmos de comprensión semántica."
        
        return f"🔧 **Análisis técnico-semántico**: '{user_input}'\n\n" \
               f"🏗️ **Framework conceptual**: {len(framework)} relaciones detectadas\n" \
               f"🎯 **Conceptos técnicos**: {', '.join(key_concepts[:3])}\n" \
               f"⚡ **Procesamiento**: Matriz semántica {semantic_data.get('semantic_analysis', {}).get('input_embedding_dim', 384)}D"
    
    def _ethical_semantic_template(self, user_input: str, key_concepts: List, framework: List, semantic_data: Dict) -> str:
        """Template para personalidad ética"""
        ethical_concepts = [concept for concept in key_concepts if any(word in concept.lower() for word in ['ético', 'moral', 'conciencia'])]
        
        return f"⚖️ **Evaluación ético-semántica**: '{user_input}'\n\n" \
               f"🧭 **Brújula moral**: {len(ethical_concepts)} dimensiones éticas identificadas\n" \
               f"🔍 **Profundidad conceptual**: {semantic_data.get('semantic_analysis', {}).get('conceptual_density', 0):.1%}\n" \
               f"💭 **Reflexión**: Las conexiones semánticas revelan capas de significado moral."
    
    def _security_semantic_template(self, user_input: str, key_concepts: List, framework: List, semantic_data: Dict) -> str:
        """Template para personalidad de seguridad"""
        security_concepts = [concept for concept in key_concepts if any(word in concept.lower() for word in ['seguridad', 'protección', 'amenaza'])]
        
        return f"🛡️ **Auditoría semántica de seguridad**: '{user_input}'\n\n" \
               f"🔒 **Elementos de seguridad**: {len(security_concepts)} patrones protectores\n" \
               f"📈 **Complejidad analizada**: Nivel {semantic_data.get('semantic_analysis', {}).get('semantic_complexity', 0.5) * 10:.0f}/10\n" \
               f"⚠️ **Estado**: Contexto semántico {len(framework)} interconexiones verificadas"

# Instancia global del redactor semántico
semantic_redactor = SemanticRedactor()

# Health check para el servicio
def health_check():
    return {
        "service": "semantic_redactor",
        "status": "operational" if semantic_redactor.enabled else "degraded",
        "semantic_universe_loaded": semantic_redactor.semantic_matrix is not None,
        "concept_count": len(semantic_redactor.concept_map),
        "embedding_dimension": semantic_redactor.embedding_dim
    }