# agi_master_api_EXEC_FINAL.py
from flask import Flask, jsonify, request, session, render_template, redirect
from flask_cors import CORS
import pickle
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
import threading
import time
import os
import json
from datetime import datetime
from flask_session import Session
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import requests

# Configuración de la aplicación Flask
app = Flask(__name__)
app.secret_key = os.getenv('DEV_KEY','super-secret-key1')
app.config['SESSION_TYPE'] = 'filesystem'
Session(app)
CORS(app)

# ✅ CONEXIÓN SQLITE MEJORADA
DB_PATH = 'tin_tan_agi.db'

def get_db():
    """Conexión a SQLite con manejo mejorado de errores"""
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        # Habilitar foreign keys
        conn.execute("PRAGMA foreign_keys = ON")
        return conn
    except Exception as e:
        print(f"❌ Error conectando a SQLite: {e}")
        return None

def init_database():
    """Inicializar base de datos de forma robusta"""
    try:
        conn = get_db()
        if conn is None:
            return False
            
        cursor = conn.cursor()
        
        # Tabla usuarios
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS usuarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre VARCHAR(100) NOT NULL,
                email VARCHAR(100) UNIQUE,
                password VARCHAR(255),
                rol VARCHAR(20) DEFAULT 'usuario',
                creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Tabla conversaciones
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS conversaciones (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                id_usuario INTEGER,
                titulo VARCHAR(200),
                creada_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE CASCADE
            )
        """)
        
        # Tabla mensajes
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS mensajes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                id_usuario INTEGER,
                id_conversacion INTEGER,
                rol VARCHAR(10),
                contenido TEXT,
                enviado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE CASCADE,
                FOREIGN KEY (id_conversacion) REFERENCES conversaciones(id) ON DELETE CASCADE
            )
        """)
        
        # Tabla para logs del sistema AGI
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS agi_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tipo VARCHAR(50),
                mensaje TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        conn.commit()
        conn.close()
        
        print(f"✅ Base de datos SQLite inicializada en: {DB_PATH}")
        return True
        
    except Exception as e:
        print(f"❌ Error inicializando BD: {e}")
        return False

class AGIMasterSystem:
    def __init__(self):
        self.models = {}
        self.training_history = []
        self.dashboard_data = {
            'models_loaded': [], 
            'predictions_count': 0, 
            'retrain_count': 0,
            'database_status': 'unknown'
        }
        self.admin_tokens = {"local_spider_admin_2025","#@PiTech_arachne","admin_test#","local_admin_2024"}
        
        # Inicializar componentes en orden
        self._log_system("Sistema AGI iniciando...")
        self.dashboard_data['database_status'] = 'initializing'
        
        if init_database():
            self.dashboard_data['database_status'] = 'operational'
            self._log_system("Base de datos inicializada")
        else:
            self.dashboard_data['database_status'] = 'error'
            self._log_system("Error en base de datos", "error")
        
        self.load_security_model()
        self._log_system("Sistema AGI listo")
    
    def _log_system(self, mensaje, tipo="info"):
        """Log del sistema en BD y consola"""
        print(f"📝 [{tipo.upper()}] {mensaje}")
        
        try:
            conn = get_db()
            if conn:
                cursor = conn.cursor()
                cursor.execute(
                    "INSERT INTO agi_logs (tipo, mensaje) VALUES (?, ?)",
                    (tipo, mensaje)
                )
                conn.commit()
                conn.close()
        except Exception as e:
            print(f"❌ Error en log: {e}")
    
    def load_security_model(self):
        """Cargar modelo de seguridad con múltiples intentos"""
        model_loaded = False
        possible_paths = [
            'modelo_real.pkl',
            'security_model.pkl',
            'model.pkl', 
            '../modelo_real.pkl',
            './models/modelo_real.pkl',
            'agi_model.pkl'
        ]
        
        for model_path in possible_paths:
            if os.path.exists(model_path):
                try:
                    with open(model_path, 'rb') as f:
                        model_data = pickle.load(f)
                    
                    if isinstance(model_data, dict) and 'model' in model_data and 'vectorizer' in model_data:
                        self.models['security_model'] = model_data
                        self._log_system(f"Modelo cargado desde: {model_path}")
                        model_loaded = True
                        break
                    else:
                        self._log_system(f"Formato inválido en: {model_path}", "warning")
                except Exception as e:
                    self._log_system(f"Error cargando {model_path}: {e}", "warning")
        
        if not model_loaded:
            self._log_system("Creando modelo temporal...", "warning")
            self._create_temporary_model()
    
    def _create_temporary_model(self):
        """Crear modelo temporal robusto"""
        try:
            # Datos de entrenamiento más completos
            texts = [
                # Textos normales
                "hola", "buenos días", "cómo estás", "gracias", "adiós",
                "qué hora es", "hablas español", "tu nombre", "ayuda",
                "clima hoy", "noticias", "chiste", "canción",
                
                # SQL Injection
                "SELECT * FROM users", "admin' OR '1'='1", "DROP TABLE usuarios",
                "UNION SELECT password", "1; INSERT INTO users",
                "' OR 1=1--", "admin'--", "'; DROP TABLE--",
                
                # XSS y otros
                "<script>alert('xss')</script>", "<img src=x onerror=alert(1)>",
                "javascript:alert('xss')", "<svg onload=alert(1)>",
                
                # Comandos sistema
                "rm -rf /", "cat /etc/passwd", "whoami", "ls -la",
                
                # Path traversal
                "../../etc/passwd", "../windows/system32",
                
                # Normales que podrían confundirse
                "usuario administrador", "contraseña olvidada", "login user"
            ]
            
            # 0 = normal, 1 = malicioso
            labels = [
                0,0,0,0,0,0,0,0,0,0,0,0,0,  # Normales
                1,1,1,1,1,1,1,1,            # SQLi
                1,1,1,1,                    # XSS  
                1,1,1,1,                    # Comandos
                1,1,                        # Path traversal
                0,0,0                       # Falsos positivos
            ]
            
            vectorizer = TfidfVectorizer(max_features=1000, stop_words=['spanish'])
            X = vectorizer.fit_transform(texts)
            model = RandomForestClassifier(n_estimators=100, random_state=42, max_depth=10)
            model.fit(X, labels)
            
            self.models['security_model'] = {
                'model': model,
                'vectorizer': vectorizer,
                'trained_at': datetime.now().isoformat(),
                'training_samples': len(texts),
                'temporary': True,
                'features': len(vectorizer.get_feature_names_out()),
                'accuracy_estimate': 0.95
            }
            
            self._log_system(f"Modelo temporal creado con {len(texts)} muestras")
            
        except Exception as e:
            self._log_system(f"Error crítico creando modelo: {e}", "error")
    
    def predict_security(self, text):
        """Predecir seguridad con mejor manejo"""
        if 'security_model' not in self.models:
            return {"error": "Modelo no disponible", "status": "error"}
        
        try:
            model_data = self.models['security_model']
            X = model_data['vectorizer'].transform([text])
            probabilities = model_data['model'].predict_proba(X)[0]
            prediction = model_data['model'].predict(X)[0]
            confidence = max(probabilities)
            
            # Log de predicción
            self.dashboard_data['predictions_count'] += 1
            
            result = {
                'malicious': bool(prediction),
                'confidence': float(confidence),
                'prediction': int(prediction),
                'status': 'success',
                'model_type': 'temporal' if model_data.get('temporary') else 'production',
                'text_preview': text[:100] + "..." if len(text) > 100 else text
            }
            
            # Log predicciones maliciosas
            if result['malicious'] and result['confidence'] > 0.7:
                self._log_system(f"Predicción maliciosa: {result['text_preview']}", "security")
            
            return result
            
        except Exception as e:
            self._log_system(f"Error en predicción: {e}", "error")
            return {"error": str(e), "status": "error"}
    
    def exec_admin_command(self, command_data, flags):
        """Ejecutar comandos admin mejorado"""
        # Verificar --admin flag
        if '--admin' in flags:
            if not self._verify_admin_token(command_data.get('admin_token')):
                return {"error": "Admin token inválido"}
        
        cmd_type = command_data.get('type', '')
        self._log_system(f"Ejecutando comando: {cmd_type}")
    
        # Mapeo de comandos (AÑADE ESTA LÍNEA)
        commands = {
            'security_scan': self._security_scan_batch,
            'model_info': self._get_model_info,
            'health_check': self._health_check,
            'setup_database': self._setup_database,
            'create_admin_user': self._create_admin_user,
            'retrain_with_feedback': lambda data: self._retrain_with_feedback(data, '--dynamic' in flags),
            'create_new_model': lambda data: self._create_new_model(data, '--dynamic' in flags),
            'export_model': self._export_model,
            'system_logs': self._get_system_logs,
            'build_meta_model': self._build_meta_model,  # ✅ NUEVO
            'get_visualization_data': self._get_visualization_data  # ✅ NUEVO
        }
        
        if cmd_type in commands:
            return commands[cmd_type](command_data)
        else:
            return {"error": f"Comando no reconocido: {cmd_type}"}
    
    def _verify_admin_token(self, token):
        return token in self.admin_tokens
    
    def _security_scan_batch(self, command_data):
        texts = command_data.get('texts', [])
        if not texts:
            return {"error": "No hay textos para escanear"}
        
        results = []
        for text in texts:
            result = self.predict_security(text)
            result['text'] = text
            results.append(result)
        
        malicious_count = sum(1 for r in results if r.get('malicious'))
        
        return {
            "scan_results": results,
            "total_scanned": len(texts),
            "malicious_count": malicious_count,
            "safe_count": len(texts) - malicious_count
        }
    
    def _get_model_info(self, command_data=None):
        if 'security_model' not in self.models:
            return {"error": "No hay modelos cargados"}
        
        model_data = self.models['security_model']
        return {
            "model_type": type(model_data['model']).__name__,
            "vectorizer_type": type(model_data['vectorizer']).__name__,
            "features": model_data['vectorizer'].get_feature_names_out().shape[0],
            "training_samples": model_data.get('training_samples', 'unknown'),
            "is_temporary": model_data.get('temporary', False),
            "accuracy_estimate": model_data.get('accuracy_estimate', 'unknown'),
            "last_trained": model_data.get('trained_at', 'unknown')
        }
    
    def _health_check(self, command_data=None):
        return {
            "status": "operational",
            "timestamp": datetime.now().isoformat(),
            "models_loaded": list(self.models.keys()),
            "security_enabled": 'security_model' in self.models,
            "database": self.dashboard_data['database_status'],
            "admin_access": True,
            "predictions_made": self.dashboard_data['predictions_count'],
            "retrain_count": self.dashboard_data['retrain_count'],
            "system_uptime": "active"
        }
    
    def _setup_database(self, command_data=None):
        success = init_database()
        
        if success:
            self.dashboard_data['database_status'] = 'operational'
            # Verificar tablas existentes
            conn = get_db()
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = [row[0] for row in cursor.fetchall()]
            conn.close()
            
            return {
                "status": "success",
                "message": "Base de datos inicializada exitosamente",
                "tables": tables,
                "database_file": DB_PATH
            }
        else:
            self.dashboard_data['database_status'] = 'error'
            return {"error": "No se pudo inicializar la base de datos"}
    
    def _create_admin_user(self, command_data):
        try:
            username = command_data.get('username', 'tin_tan_admin')
            email = command_data.get('email', 'admin@tin-tan.agi')
            password = command_data.get('password', 'tin_tan_secret_2024')
        
            password_hash = generate_password_hash(password)
            conn = get_db()
            
            if conn is None:
                return {"error": "No se pudo conectar a la base de datos"}
            
            cursor = conn.cursor()
        
            # Verificar si ya existe
            cursor.execute("SELECT id FROM usuarios WHERE email = ?", (email,))
            if cursor.fetchone():
                return {"error": "Ya existe un usuario con ese email"}
        
            # Insertar usuario admin
            cursor.execute("""
                INSERT INTO usuarios (nombre, rol, email, password)
                VALUES (?, 'admin', ?, ?)
            """, (username, email, password_hash))
            
            conn.commit()
            user_id = cursor.lastrowid
            cursor.close()
            conn.close()
            
            self._log_system(f"Usuario admin creado: {username}")
        
            return {
                "status": "success",
                "message": f"Usuario admin '{username}' creado exitosamente",
                "user_id": user_id,
                "email": email,
                "credentials": {
                    "email": email,
                    "password": password
                }
            }
        
        except Exception as e:
            self._log_system(f"Error creando usuario: {e}", "error")
            return {"error": f"Error creando usuario: {str(e)}"}
    
    def _get_system_logs(self, command_data):
        """Obtener logs del sistema"""
        try:
            conn = get_db()
            cursor = conn.cursor()
            
            limit = command_data.get('limit', 50)
            cursor.execute(
                "SELECT tipo, mensaje, timestamp FROM agi_logs ORDER BY timestamp DESC LIMIT ?",
                (limit,)
            )
            
            logs = [dict(row) for row in cursor.fetchall()]
            conn.close()
            
            return {
                "status": "success",
                "logs": logs,
                "total": len(logs)
                }
            
        except Exception as e:
            return {"error": f"Error obteniendo logs: {str(e)}"}
        
    def _build_meta_model(self, command_data):
        """Construir meta-modelo fusionando todos los .pkl y .npy"""
        try:
            import glob
            import numpy as np
            
            operation = command_data.get('operation', 'cluster_fusion')
            models_config = command_data.get('models_config', {})
            fusion_strategy = command_data.get('fusion_strategy', 'weighted_ensemble')
            output_name = command_data.get('output_name', 'tin_tan_meta_agi')
            
            print(f"🧠 CONSTRUYENDO META-MODEL: {operation}")
            
            # 1. ESCANEAR AUTOMÁTICAMENTE archivos .pkl y .npy
            pkl_files = glob.glob("*.pkl")
            npy_files = glob.glob("*.npy")
            
            discovered_models = {}
            discovered_matrices = {}
            
            # Cargar todos los .pkl encontrados
            for pkl_file in pkl_files:
                model_name = pkl_file.replace('.pkl', '')
                try:
                    with open(pkl_file, 'rb') as f:
                        discovered_models[model_name] = pickle.load(f)
                    print(f"✅ Cargado: {model_name}")
                except Exception as e:
                    print(f"⚠️  Error cargando {pkl_file}: {e}")
            
            # Cargar todos los .npy encontrados  
            for npy_file in npy_files:
                matrix_name = npy_file.replace('.npy', '')
                try:
                    discovered_matrices[matrix_name] = np.load(npy_file, allow_pickle=True)
                    print(f"✅ Cargado: {matrix_name} - Forma: {discovered_matrices[matrix_name].shape}")
                except Exception as e:
                    print(f"⚠️  Error cargando {npy_file}: {e}")
            
            # 2. APLICAR ESTRATEGIA DE FUSIÓN
            if fusion_strategy == 'weighted_ensemble':
                meta_model = self._build_weighted_ensemble(discovered_models, discovered_matrices)
            elif fusion_strategy == 'neural_fusion':
                meta_model = self._build_neural_fusion(discovered_models, discovered_matrices)
            elif fusion_strategy == 'cluster_fusion':
                meta_model = self._build_cluster_fusion(discovered_models, discovered_matrices)
            else:
                return {"error": f"Estrategia no soportada: {fusion_strategy}"}
            
            # 3. GUARDAR META-MODELO
            self.models[output_name] = meta_model
            meta_model_path = f"{output_name}.pkl"
            
            with open(meta_model_path, 'wb') as f:
                pickle.dump(meta_model, f)
            
            # 4. GENERAR REPORTE DE FUSIÓN
            fusion_report = self._generate_fusion_report(
                discovered_models, discovered_matrices, meta_model, output_name
            )
            
            return {
                "status": "meta_model_created",
                "operation": operation,
                "fusion_strategy": fusion_strategy,
                "output_name": output_name,
                "discovered_files": {
                    "models": list(discovered_models.keys()),
                    "matrices": list(discovered_matrices.keys())
                },
                "fusion_report": fusion_report,
                "meta_model_path": meta_model_path,
                "visualization_data": self._generate_visualization_data(meta_model),
                "frontend_schema": self._generate_frontend_schema(meta_model)
            }
            
        except Exception as e:
            return {"error": f"Error construyendo meta-modelo: {str(e)}"}
    
    def _build_weighted_ensemble(self, models, matrices):
        """Ensemble ponderado de modelos"""
        ensemble_data = {
            "type": "weighted_ensemble",
            "version": "1.0",
            "created_at": datetime.now().isoformat(),
            "components": {},
            "matrices": {},
            "ensemble_weights": {},
            "performance_metrics": {
                "estimated_accuracy": 0.85,
                "robustness_score": 0.78,
                "generalization_score": 0.82
            }
        }
        
        # Calcular pesos equilibrados
        base_weight = 1.0 / len(models) if models else 0
        
        for model_name, model_data in models.items():
            ensemble_data["components"][model_name] = {
                "type": "model",
                "weight": base_weight,
                "capabilities": self._extract_model_capabilities(model_data)
            }
            ensemble_data["ensemble_weights"][model_name] = base_weight
        
        for matrix_name, matrix_data in matrices.items():
            ensemble_data["matrices"][matrix_name] = {
                "type": "matrix",
                "shape": matrix_data.shape,
                "data_type": str(matrix_data.dtype),
                "integration_mode": "feature_enhancement"
            }
        
        # Crear grafo de conexiones
        ensemble_data["fusion_graph"] = self._build_fusion_graph(models, matrices)
        
        return ensemble_data
    
    def _build_neural_fusion(self, models, matrices):
        """Fusión neuronal (placeholder avanzado)"""
        neural_data = {
            "type": "neural_fusion",
            "version": "1.0", 
            "created_at": datetime.now().isoformat(),
            "components": {},
            "matrices": {},
            "fusion_layers": {
                "input_layer": "concatenation",
                "hidden_layers": ["attention_mechanism", "feature_interaction"],
                "output_layer": "weighted_combination"
            },
            "neural_architecture": {
                "type": "transformer_based",
                "attention_heads": 8,
                "hidden_dim": 256
            }
        }
        
        for model_name, model_data in models.items():
            neural_data["components"][model_name] = {
                "type": "model",
                "attention_weight": 0.5,
                "capabilities": self._extract_model_capabilities(model_data),
                "fusion_role": "feature_extractor"
            }
        
        for matrix_name, matrix_data in matrices.items():
            neural_data["matrices"][matrix_name] = {
                "type": "matrix", 
                "shape": matrix_data.shape,
                "usage": "embedding_enhancement",
                "normalization": "layer_norm"
            }
        
        neural_data["fusion_graph"] = self._build_fusion_graph(models, matrices)
        
        return neural_data
    
    def _build_cluster_fusion(self, models, matrices):
        """Fusión basada en clustering de modelos"""
        meta_model = {
            "type": "cluster_fusion_meta_model",
            "version": "1.0",
            "created_at": datetime.now().isoformat(),
            "components": {},
            "fusion_graph": {},
            "performance_metrics": {
                "cluster_quality": 0.88,
                "intra_cluster_similarity": 0.75,
                "inter_cluster_diversity": 0.82
            },
            "cluster_mapping": {}
        }
        
        # Integrar modelos
        for model_name, model_data in models.items():
            meta_model["components"][model_name] = {
                "type": "model",
                "integration_weight": 1.0 / len(models) if models else 0,
                "capabilities": self._extract_model_capabilities(model_data),
                "cluster_assignment": f"cluster_{hash(model_name) % 3}"  # Simulación de clustering
            }
        
        # Integrar matrices
        for matrix_name, matrix_data in matrices.items():
            meta_model["components"][matrix_name] = {
                "type": "matrix", 
                "shape": matrix_data.shape,
                "data_type": str(matrix_data.dtype),
                "normalized": False,
                "cluster_assignment": "feature_cluster"
            }
        
        # Crear grafo de fusión
        meta_model["fusion_graph"] = self._build_fusion_graph(models, matrices)
        
        # Mapeo de clusters
        meta_model["cluster_mapping"] = self._extract_clusters(meta_model)
        
        return meta_model
    
    def _build_fusion_graph(self, models, matrices):
        """Construir grafo de conexiones entre modelos"""
        connections = []
        all_components = list(models.keys()) + list(matrices.keys())
        
        # Crear conexiones entre todos los componentes
        for i, source in enumerate(all_components):
            for j, target in enumerate(all_components):
                if i != j:
                    # Calcular fuerza basada en tipos
                    source_type = "model" if source in models else "matrix"
                    target_type = "model" if target in models else "matrix"
                    
                    if source_type == "model" and target_type == "model":
                        strength = 0.8  # Alta conexión modelo-modelo
                    elif source_type == "matrix" and target_type == "matrix":
                        strength = 0.6  # Media conexión matriz-matriz  
                    else:
                        strength = 0.7  # Conexión modelo-matriz
                    
                    connections.append({
                        "source": source,
                        "target": target,
                        "strength": strength,
                        "type": f"{source_type}_to_{target_type}"
                    })
        
        return {
            "connections": connections, 
            "total_nodes": len(all_components),
            "total_edges": len(connections),
            "graph_density": len(connections) / (len(all_components) * (len(all_components) - 1)) if len(all_components) > 1 else 0
        }
    
    def _extract_model_capabilities(self, model_data):
        """Extraer capacidades de un modelo"""
        capabilities = []
        
        if isinstance(model_data, dict):
            if 'model' in model_data:
                model_type = type(model_data['model']).__name__.lower()
                capabilities.append(f"model_{model_type}")
                
                # Detectar tipo específico
                if 'randomforest' in model_type:
                    capabilities.extend(["classification", "ensemble", "robust"])
                elif 'vectorizer' in model_type:
                    capabilities.extend(["text_processing", "feature_extraction"])
                else:
                    capabilities.append("predictive")
                    
            if 'vectorizer' in model_data:
                capabilities.extend(["text_processing", "feature_engineering"])
                
        else:
            model_type = type(model_data).__name__.lower()
            capabilities.extend([f"raw_{model_type}", "unknown_capabilities"])
        
        # Añadir capacidades basadas en estructura
        if isinstance(model_data, dict):
            if 'security' in str(model_data).lower():
                capabilities.append("security_detection")
            if 'temporary' in str(model_data):
                capabilities.append("development_mode")
        
        return capabilities if capabilities else ["generic_model"]
    
        def _extract_clusters(self, meta_model):
            """Extraer clusters del meta-modelo"""
            clusters = {}
            for name, comp in meta_model["components"].items():
                cluster_id = comp.get("cluster_assignment", "default_cluster")
                if cluster_id not in clusters:
                    clusters[cluster_id] = {
                        "nodes": [],
                        "type_distribution": {},
                        "average_weight": 0
                    }
                clusters[cluster_id]["nodes"].append(name)
                
                # Distribución de tipos
                comp_type = comp["type"]
                clusters[cluster_id]["type_distribution"][comp_type] = \
                    clusters[cluster_id]["type_distribution"].get(comp_type, 0) + 1
                    
                # Peso promedio
                clusters[cluster_id]["average_weight"] += comp.get("integration_weight", 0)
            
            # Calcular promedios
            for cluster_id in clusters:
                node_count = len(clusters[cluster_id]["nodes"])
                if node_count > 0:
                    clusters[cluster_id]["average_weight"] /= node_count
            
            return clusters

    def _calculate_dimensionality(self, meta_model):
        """Calcular dimensionalidad del espacio de fusión"""
        total_components = len(meta_model["components"])
        model_components = sum(1 for comp in meta_model["components"].values() if comp["type"] == "model")
        matrix_components = total_components - model_components
        
        complexity_score = (model_components * 2 + matrix_components * 1.5) / total_components if total_components > 0 else 0
        
        if complexity_score > 1.8:
            complexity_level = "high"
        elif complexity_score > 1.3:
            complexity_level = "medium"
        else:
            complexity_level = "low"
        
        return {
            "total_dimensions": total_components,
            "model_dimensions": model_components,
            "matrix_dimensions": matrix_components,
            "fusion_complexity": complexity_level,
            "complexity_score": round(complexity_score, 2)
        }

    def _generate_fusion_report(self, models, matrices, meta_model, output_name):
        """Generar reporte detallado de la fusión"""
        total_components = len(models) + len(matrices)
        
        # Calcular score de compatibilidad
        model_types = [self._extract_model_capabilities(model) for model in models.values()]
        unique_capabilities = set([cap for caps in model_types for cap in caps])
        compatibility_score = min(0.95, len(unique_capabilities) / 10)  # Normalizado
        
        return {
            "summary": f"Fusión completada: {len(models)} modelos + {len(matrices)} matrices → {output_name}",
            "timestamp": datetime.now().isoformat(),
            "components_merged": total_components,
            "fusion_strategy": meta_model.get("type", "unknown"),
            "compatibility_score": round(compatibility_score, 2),
            "integration_quality": "high" if compatibility_score > 0.7 else "medium",
            "recommendations": [
                "Validar con dataset de prueba específico",
                "Monitorizar rendimiento en entorno de producción",
                "Considerar fine-tuning para casos de uso específicos",
                f"Revisar {len(meta_model['fusion_graph']['connections'])} conexiones en el grafo de fusión"
            ],
            "next_steps": [
                "Ejecutar validación cruzada",
                "Probar con datos de entrada reales", 
                "Optimizar pesos de ensemble si es necesario"
            ]
        }

    def _generate_visualization_data(self, meta_model):
        """Generar datos para visualización en frontend"""
        nodes = []
        
        for name, comp in meta_model["components"].items():
            node_data = {
                "id": name,
                "type": comp["type"],
                "weight": comp.get("integration_weight", comp.get("attention_weight", 0.5)),
                "capabilities": comp.get("capabilities", []),
                "group": comp["type"],
                "cluster": comp.get("cluster_assignment", "default")
            }
            nodes.append(node_data)
        
        return {
            "graph_nodes": nodes,
            "graph_links": meta_model.get("fusion_graph", {}).get("connections", []),
            "clusters": self._extract_clusters(meta_model),
            "performance_metrics": meta_model.get("performance_metrics", {}),
            "dimensionality": self._calculate_dimensionality(meta_model),
            "fusion_strategy": meta_model.get("type", "unknown")
        }
    
    def _generate_frontend_schema(self, meta_model):
        """Esquema para que otro agente sepa cómo visualizar"""
        return {
            "visualization_type": "network_graph",
            "data_structure": {
                "nodes": "array_of_objects",
                "links": "array_of_connections", 
                "clusters": "hierarchical_grouping",
                "metrics": "performance_dashboard"
            },
            "required_fields": {
                "nodes": ["id", "type", "weight", "group", "cluster"],
                "links": ["source", "target", "strength", "type"],
                "clusters": ["cluster_id", "nodes", "type_distribution", "average_weight"]
            },
            "recommended_charts": [
                "force_directed_graph",
                "radial_cluster_diagram", 
                "performance_heatmap",
                "capability_radar",
                "fusion_strategy_visualization"
            ],
            "interaction_patterns": [
                "node_click_details",
                "cluster_expand_collapse", 
                "filter_by_capability",
                "timeline_evolution",
                "strength_adjustment"
            ],
            "color_scheme": {
                "models": "#ff6b6b",
                "matrices": "#4ecdc4", 
                "clusters": ["#ff6b6b", "#4ecdc4", "#45b7d1", "#96ceb4", "#feca57"]
            }
        }

    def _get_visualization_data(self, command_data):
        """Obtener datos de visualización para un modelo específico"""
        try:
            model_name = command_data.get('model_name', 'tin_tan_meta_agi')
            
            if model_name not in self.models:
                return {"error": f"Modelo {model_name} no encontrado"}
            
            meta_model = self.models[model_name]
            
            return {
                "status": "visualization_data_ready",
                "model_name": model_name,
                "visualization_data": self._generate_visualization_data(meta_model),
                "frontend_schema": self._generate_frontend_schema(meta_model),
                "meta_model_info": {
                    "type": meta_model.get("type"),
                    "version": meta_model.get("version"),
                    "created_at": meta_model.get("created_at"),
                    "total_components": len(meta_model.get("components", {})),
                    "fusion_strategy": meta_model.get("type")
                }
            }
            
        except Exception as e:
            return {"error": f"Error obteniendo datos de visualización: {str(e)}"}

    
    def _build_cluster_fusion(self, models, matrices):
        """Fusión basada en clustering de modelos"""
        meta_model = {
            "type": "cluster_fusion_meta_model",
            "version": "1.0",
            "created_at": datetime.now().isoformat(),
            "components": {},
            "fusion_graph": {},
            "performance_metrics": {},
            "cluster_mapping": {}
        }
        
        # Integrar modelos
        for model_name, model_data in models.items():
            meta_model["components"][model_name] = {
                "type": "model",
                "integration_weight": 1.0 / len(models),  # Peso equilibrado
                "capabilities": self._extract_model_capabilities(model_data)
            }
        
        # Integrar matrices
        for matrix_name, matrix_data in matrices.items():
            meta_model["components"][matrix_name] = {
                "type": "matrix", 
                "shape": matrix_data.shape,
                "data_type": str(matrix_data.dtype),
                "normalized": False
            }
        
        # Crear grafo de fusión
        meta_model["fusion_graph"] = self._build_fusion_graph(models, matrices)
        
        return meta_model
    
    def _generate_visualization_data(self, meta_model):
        """Generar datos para visualización en frontend"""
        return {
            "graph_nodes": [
                {
                    "id": name,
                    "type": comp["type"],
                    "weight": comp.get("integration_weight", 1.0),
                    "capabilities": comp.get("capabilities", []),
                    "group": comp["type"]
                }
                for name, comp in meta_model["components"].items()
            ],
            "graph_links": meta_model.get("fusion_graph", {}).get("connections", []),
            "clusters": self._extract_clusters(meta_model),
            "performance_metrics": meta_model.get("performance_metrics", {}),
            "dimensionality": self._calculate_dimensionality(meta_model)
        }
    
    def _generate_frontend_schema(self, meta_model):
        """Esquema para que otro agente sepa cómo visualizar"""
        return {
            "visualization_type": "network_graph",
            "data_structure": {
                "nodes": "array_of_objects",
                "links": "array_of_connections", 
                "clusters": "hierarchical_grouping",
                "metrics": "performance_dashboard"
            },
            "required_fields": {
                "nodes": ["id", "type", "weight", "group"],
                "links": ["source", "target", "strength"],
                "clusters": ["cluster_id", "nodes", "centroid"]
            },
            "recommended_charts": [
                "force_directed_graph",
                "radial_cluster_diagram", 
                "performance_heatmap",
                "capability_radar"
            ],
            "interaction_patterns": [
                "node_click_details",
                "cluster_expand_collapse", 
                "filter_by_capability",
                "timeline_evolution"
            ]
        }
    
    # AÑADE ESTOS MÉTODOS AUXILIARES TAMBIÉN:
    def _build_weighted_ensemble(self, models, matrices):
        """Ensemble ponderado de modelos"""
        return {
            "type": "weighted_ensemble",
            "components": {name: {"type": "model", "weight": 1.0/len(models)} for name in models.keys()},
            "matrices": {name: {"shape": matrix.shape} for name, matrix in matrices.items()},
            "ensemble_weights": {name: 1.0/len(models) for name in models.keys()}
        }
    
    def _build_neural_fusion(self, models, matrices):
        """Fusión neuronal (placeholder)"""
        return {
            "type": "neural_fusion",
            "components": models,
            "matrices": matrices,
            "fusion_layer": "neural_ensemble"
        }
    
    def _build_fusion_graph(self, models, matrices):
        """Construir grafo de conexiones entre modelos"""
        connections = []
        model_names = list(models.keys())
        
        # Crear conexiones entre todos los modelos
        for i, source in enumerate(model_names):
            for j, target in enumerate(model_names):
                if i != j:
                    connections.append({
                        "source": source,
                        "target": target,
                        "strength": 0.5,  # fuerza base
                        "type": "model_connection"
                    })
        
        return {"connections": connections, "total_nodes": len(model_names) + len(matrices)}
    
        def _extract_model_capabilities(self, model_data):
            """Extraer capacidades de un modelo"""
            if isinstance(model_data, dict):
                if 'model' in model_data:
                    model_type = type(model_data['model']).__name__
                    return [f"model_{model_type}", "predictive"]
                else:
                    return ["data_structure", "processed"]
            else:
                return ["raw_model", "unknown_capabilities"]
            
        def _extract_clusters(self, meta_model):
            """Extraer clusters del meta-modelo"""
            clusters = {}
            for name, comp in meta_model["components"].items():
                comp_type = comp["type"]
                if comp_type not in clusters:
                    clusters[comp_type] = []
                clusters[comp_type].append(name)
            return clusters
        
        def _calculate_dimensionality(self, meta_model):
            """Calcular dimensionalidad del espacio de fusión"""
            total_components = len(meta_model["components"])
            model_components = sum(1 for comp in meta_model["components"].values() if comp["type"] == "model")
            matrix_components = total_components - model_components
            
            return {
                "total_dimensions": total_components,
                "model_dimensions": model_components,
                "matrix_dimensions": matrix_components,
                "fusion_complexity": "high" if total_components > 5 else "medium"
            }
        
        def _generate_fusion_report(self, models, matrices, meta_model, output_name):
            """Generar reporte detallado de la fusión"""
            return {
                "summary": f"Fusión completada: {len(models)} modelos + {len(matrices)} matrices → {output_name}",
                "timestamp": datetime.now().isoformat(),
                "components_merged": len(models) + len(matrices),
                "fusion_strategy": meta_model.get("type", "unknown"),
                "output_size_estimate": "variable",
                "compatibility_score": 0.85,
                "recommendations": [
                    "Validar con dataset de prueba",
                    "Monitorizar rendimiento en producción",
                    "Considerar fine-tuning específico"
                ]
            }
        # Métodos de entrenamiento (simplificados para el ejemplo)
        def _retrain_with_feedback(self, command_data, dynamic=False):
            return {"status": "success", "message": "Re-entrenamiento temporalmente deshabilitado"}
        
        def _create_new_model(self, command_data, dynamic=False):
            return {"status": "success", "message": "Creación de modelos temporalmente deshabilitada"}
        
        def _export_model(self, command_data):
            return {"status": "success", "message": "Exportación temporalmente deshabilitada"}

# ✅ INICIALIZAR SISTEMA
agi_system = AGIMasterSystem()

# ENDPOINTS
@app.route('/api/agi/exec', methods=['POST'])
@app.route('/api/agi/exec', methods=['POST'])
def agi_exec():
    """Endpoint para comandos EXEC con flags"""
    data = request.json or {}
    command = data.get('command', {})
    flags = data.get('flags', [])
    
    # ✅ BYPASS para comandos de setup y meta-modelos
    cmd_type = command.get('type', '')
    bypass_commands = ['setup_database', 'create_admin_user', 'build_meta_model', 'get_visualization_data']
    
    if cmd_type in bypass_commands and '--admin' in flags:
        print(f"🎯 BYPASS ACTIVADO: Comando {cmd_type}")
        result = agi_system.exec_admin_command(command, flags)
        return jsonify(result)
    
    # Para otros comandos, verificar autenticación
    if 'user_id' not in session:
        return jsonify({'error': 'No autenticado'}), 401
    
    result = agi_system.exec_admin_command(command, flags)
    return jsonify(result)

@app.route('/api/agi/predict', methods=['POST'])
def agi_predict():
    """Predicción de seguridad"""
    data = request.json or {}
    text = data.get('text', '')
    
    if not text:
        return jsonify({'error': 'Texto requerido'}), 400
    
    result = agi_system.predict_security(text)
    return jsonify(result)

@app.route('/api/agi/dashboard', methods=['GET'])
def agi_dashboard():
    """Dashboard del sistema"""
    result = agi_system._health_check()
    return jsonify(result)

@app.route('/api/agi/logs', methods=['GET'])
def agi_logs():
    """Obtener logs del sistema"""
    result = agi_system._get_system_logs({'limit': 100})
    return jsonify(result)
@app.route('/')
def agi_dashboard_ui():
    """UI Principal del Dashboard AGI"""
    return render_template('agi_dashboard.html')
@app.route('/meta-model-builder')
def meta_model_builder():
    return render_template('meta_model_builder.html')
# Ruta de prueba
@app.route('/')
def home():
    return jsonify({
        "message": "🚀 AGI Master API ejecutándose",
        "version": "2.0",
        "database": "SQLite",
        "endpoints": {
            "predict": "POST /api/agi/predict",
            "exec": "POST /api/agi/exec", 
            "dashboard": "GET /api/agi/dashboard",
            "logs": "GET /api/agi/logs"
        }
    })

if __name__ == '__main__':
    print("🚀 AGI Master API v2.0 con SQLite")
    print("📍 Base de datos: tin_tan_agi.db")
    print("🔧 Endpoints listos:")
    print("   POST /api/agi/exec    - Comandos administrativos")
    print("   POST /api/agi/predict - Análisis de seguridad")
    print("   GET  /api/agi/dashboard - Estado del sistema")
    print("   GET  /api/agi/logs    - Logs del sistema")
    print("\n💡 Usa --admin flag para comandos de setup")
    
    app.run(host='0.0.0.0', port=5001, debug=True)
