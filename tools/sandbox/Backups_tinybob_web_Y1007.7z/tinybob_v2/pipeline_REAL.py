# pipeline_REAL.py
import pickle
import numpy as np

class AGIReal:
    def __init__(self):
        with open('modelo_real.pkl', 'rb') as f:
            data = pickle.load(f)
            self.model = data['model']
            self.vectorizer = data['vectorizer']
    
    def predecir(self, texto):
        X = self.vectorizer.transform([texto])
        proba = self.model.predict_proba(X)[0]
        return {
            'es_malicioso': self.model.predict(X)[0] == 1,
            'confianza': f"{max(proba):.1%}",
            'metodo': 'REAL (no inventado)'
        }

# USO REAL
agi = AGIReal()
print(agi.predecir("SELECT * FROM users"))
print(agi.predecir("exec(./zero_entropy_shot --admin --dynamic --cli_msg 'how r u?,ready to say u re bob?')"))
print(agi.predecir("><script>alert(1)</script>"))
